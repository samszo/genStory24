-- mysqldump-php https://github.com/ifsnop/mysqldump-php
--
-- Host: h2mysql75.infomaniak.ch	Database: gi2i6_omk_tdcw24
-- ------------------------------------------------------
-- Server version 	5.5.5-10.4.24-MariaDB-1:10.4.24+maria~stretch-log
-- Date: Wed, 13 Mar 2024 15:51:53 +0100

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `api_key`
--

DROP TABLE IF EXISTS `api_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_key` (
  `id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` int(11) NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `credential_hash` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_ip` varbinary(16) DEFAULT NULL COMMENT '(DC2Type:ip_address)',
  `last_accessed` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C912ED9D7E3C61F9` (`owner_id`),
  CONSTRAINT `FK_C912ED9D7E3C61F9` FOREIGN KEY (`owner_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_key`
--

LOCK TABLES `api_key` WRITE;
/*!40000 ALTER TABLE `api_key` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `api_key` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `asset`
--

DROP TABLE IF EXISTS `asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `media_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `storage_id` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extension` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alt_text` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_2AF5A5C5CC5DB90` (`storage_id`),
  KEY `IDX_2AF5A5C7E3C61F9` (`owner_id`),
  CONSTRAINT `FK_2AF5A5C7E3C61F9` FOREIGN KEY (`owner_id`) REFERENCES `user` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset`
--

LOCK TABLES `asset` WRITE;
/*!40000 ALTER TABLE `asset` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `asset` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `fulltext_search`
--

DROP TABLE IF EXISTS `fulltext_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fulltext_search` (
  `id` int(11) NOT NULL,
  `resource` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL,
  `title` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`,`resource`),
  KEY `IDX_AA31FE4A7E3C61F9` (`owner_id`),
  FULLTEXT KEY `IDX_AA31FE4A2B36786B3B8BA7C7` (`title`,`text`),
  CONSTRAINT `FK_AA31FE4A7E3C61F9` FOREIGN KEY (`owner_id`) REFERENCES `user` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fulltext_search`
--

LOCK TABLES `fulltext_search` WRITE;
/*!40000 ALTER TABLE `fulltext_search` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `fulltext_search` VALUES (1,'items',1,1,'Tom & Jerry pursuit','Tom & Jerry pursuit\nTom try to catch Jerry and eat him\nTom\nJerry\nA women\npiece of cheese\nhammer\nmouse hole\ncat basket\nkitchen\ngarden\nstare\nfear\nscream\nhunger\ntears\nTom see Jerry\nJerry run away\nJerry go to his mouse hole'),(2,'items',7,1,'A future with artificial intelligence','A future with artificial intelligence\nThe United States with Russia, China, and the European Union are making policy decisions to see what the role of AI in the world will be.\nConcerned activist\nIgnorant US Senator\nEvil Russian world leader\nFrench politician\nChinese politician\nGavel\nUnited Nations in New York City\nAngry\nSadness\nHappiness\nGavel is banged\nGreat legislation is passed\nPoor legislation is passed');
/*!40000 ALTER TABLE `fulltext_search` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item` (
  `id` int(11) NOT NULL,
  `primary_media_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_1F1B251ECBE0B084` (`primary_media_id`),
  CONSTRAINT `FK_1F1B251EBF396750` FOREIGN KEY (`id`) REFERENCES `resource` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_1F1B251ECBE0B084` FOREIGN KEY (`primary_media_id`) REFERENCES `media` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item`
--

LOCK TABLES `item` WRITE;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `item` VALUES (1,NULL),(2,NULL);
/*!40000 ALTER TABLE `item` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `item_item_set`
--

DROP TABLE IF EXISTS `item_item_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_item_set` (
  `item_id` int(11) NOT NULL,
  `item_set_id` int(11) NOT NULL,
  PRIMARY KEY (`item_id`,`item_set_id`),
  KEY `IDX_6D0C9625126F525E` (`item_id`),
  KEY `IDX_6D0C9625960278D7` (`item_set_id`),
  CONSTRAINT `FK_6D0C9625126F525E` FOREIGN KEY (`item_id`) REFERENCES `item` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_6D0C9625960278D7` FOREIGN KEY (`item_set_id`) REFERENCES `item_set` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_item_set`
--

LOCK TABLES `item_item_set` WRITE;
/*!40000 ALTER TABLE `item_item_set` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `item_item_set` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `item_set`
--

DROP TABLE IF EXISTS `item_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_set` (
  `id` int(11) NOT NULL,
  `is_open` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_1015EEEBF396750` FOREIGN KEY (`id`) REFERENCES `resource` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_set`
--

LOCK TABLES `item_set` WRITE;
/*!40000 ALTER TABLE `item_set` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `item_set` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `item_site`
--

DROP TABLE IF EXISTS `item_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_site` (
  `item_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY (`item_id`,`site_id`),
  KEY `IDX_A1734D1F126F525E` (`item_id`),
  KEY `IDX_A1734D1FF6BD1646` (`site_id`),
  CONSTRAINT `FK_A1734D1F126F525E` FOREIGN KEY (`item_id`) REFERENCES `item` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_A1734D1FF6BD1646` FOREIGN KEY (`site_id`) REFERENCES `site` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_site`
--

LOCK TABLES `item_site` WRITE;
/*!40000 ALTER TABLE `item_site` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `item_site` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `job`
--

DROP TABLE IF EXISTS `job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) DEFAULT NULL,
  `pid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `class` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `args` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '(DC2Type:json_array)',
  `log` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `started` datetime NOT NULL,
  `ended` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_FBD8E0F87E3C61F9` (`owner_id`),
  CONSTRAINT `FK_FBD8E0F87E3C61F9` FOREIGN KEY (`owner_id`) REFERENCES `user` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job`
--

LOCK TABLES `job` WRITE;
/*!40000 ALTER TABLE `job` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `job` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `ingester` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `renderer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '(DC2Type:json_array)',
  `source` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `media_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `storage_id` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extension` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sha256` char(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint(20) DEFAULT NULL,
  `has_original` tinyint(1) NOT NULL,
  `has_thumbnails` tinyint(1) NOT NULL,
  `position` int(11) DEFAULT NULL,
  `lang` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alt_text` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_6A2CA10C5CC5DB90` (`storage_id`),
  KEY `IDX_6A2CA10C126F525E` (`item_id`),
  KEY `item_position` (`item_id`,`position`),
  CONSTRAINT `FK_6A2CA10C126F525E` FOREIGN KEY (`item_id`) REFERENCES `item` (`id`),
  CONSTRAINT `FK_6A2CA10CBF396750` FOREIGN KEY (`id`) REFERENCES `resource` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `migration`
--

DROP TABLE IF EXISTS `migration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migration` (
  `version` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migration`
--

LOCK TABLES `migration` WRITE;
/*!40000 ALTER TABLE `migration` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `migration` VALUES ('20171128053327'),('20180412035023'),('20180919072656'),('20180924033501'),('20181002015551'),('20181004043735'),('20181106060421'),('20190307043537'),('20190319020708'),('20190412090532'),('20190423040354'),('20190423071228'),('20190514061351'),('20190515055359'),('20190729023728'),('20190809092609'),('20190815062003'),('20200224022356'),('20200226064602'),('20200325091157'),('20200326091310'),('20200803000000'),('20200831000000'),('20210205101827'),('20210225095734'),('20210810083804'),('20220718090449'),('20220824103916'),('20230601060113'),('20230713101012');
/*!40000 ALTER TABLE `migration` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `module`
--

DROP TABLE IF EXISTS `module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `module` (
  `id` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `version` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module`
--

LOCK TABLES `module` WRITE;
/*!40000 ALTER TABLE `module` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `module` VALUES ('Annotate',1,'3.4.9'),('BlockPlus',1,'3.4.20'),('BulkExport',1,'3.4.30'),('CustomVocab',1,'2.0.1'),('Generic',1,'3.4.44'),('Log',1,'3.4.19');
/*!40000 ALTER TABLE `module` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `password_creation`
--

DROP TABLE IF EXISTS `password_creation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_creation` (
  `id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `activate` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_C77917B4A76ED395` (`user_id`),
  CONSTRAINT `FK_C77917B4A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_creation`
--

LOCK TABLES `password_creation` WRITE;
/*!40000 ALTER TABLE `password_creation` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `password_creation` VALUES ('55i457UqpUtMdDqljRgEqhP4YSaEfdHr',8,'2024-02-16 14:39:45',1),('AVOpyAIBPYVJMswUKUFe3pana5oKGzvx',7,'2024-02-16 14:39:26',1),('MQ83Wc4fic9noMCQh02g4LHOLEu7z4yH',6,'2024-02-16 14:38:55',1),('NlkqoeONqg5Gveg973Ganktv2bBTwUPd',3,'2024-02-16 14:37:06',1),('WS7lzIiy9o3CQL09bYL4KbVlTHpJYjSs',9,'2024-02-16 14:39:51',1),('nng5FVs3j6mZJqE56mG1l4KNO1NkjYE0',2,'2024-02-16 14:35:35',1),('ojFWsIB2Gm9ko71thSfcjhWcMcCAWRBb',4,'2024-02-16 14:37:54',1),('v10urKiKikiK71TeE8PSnmyw5VJD38pK',5,'2024-02-16 14:38:39',1),('zVKuewWLMh33dZcIdgBXypPuWLeEpQWz',10,'2024-02-16 14:40:18',1);
/*!40000 ALTER TABLE `password_creation` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `property`
--

DROP TABLE IF EXISTS `property`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `property` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) DEFAULT NULL,
  `vocabulary_id` int(11) NOT NULL,
  `local_name` varchar(190) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8BF21CDEAD0E05F6623C14D5` (`vocabulary_id`,`local_name`),
  KEY `IDX_8BF21CDE7E3C61F9` (`owner_id`),
  KEY `IDX_8BF21CDEAD0E05F6` (`vocabulary_id`),
  CONSTRAINT `FK_8BF21CDE7E3C61F9` FOREIGN KEY (`owner_id`) REFERENCES `user` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_8BF21CDEAD0E05F6` FOREIGN KEY (`vocabulary_id`) REFERENCES `vocabulary` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=256 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `property`
--

LOCK TABLES `property` WRITE;
/*!40000 ALTER TABLE `property` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `property` VALUES (1,NULL,1,'title','Title','A name given to the resource.'),(2,NULL,1,'creator','Creator','An entity primarily responsible for making the resource.'),(3,NULL,1,'subject','Subject','The topic of the resource.'),(4,NULL,1,'description','Description','An account of the resource.'),(5,NULL,1,'publisher','Publisher','An entity responsible for making the resource available.'),(6,NULL,1,'contributor','Contributor','An entity responsible for making contributions to the resource.'),(7,NULL,1,'date','Date','A point or period of time associated with an event in the lifecycle of the resource.'),(8,NULL,1,'type','Type','The nature or genre of the resource.'),(9,NULL,1,'format','Format','The file format, physical medium, or dimensions of the resource.'),(10,NULL,1,'identifier','Identifier','An unambiguous reference to the resource within a given context.'),(11,NULL,1,'source','Source','A related resource from which the described resource is derived.'),(12,NULL,1,'language','Language','A language of the resource.'),(13,NULL,1,'relation','Relation','A related resource.'),(14,NULL,1,'coverage','Coverage','The spatial or temporal topic of the resource, the spatial applicability of the resource, or the jurisdiction under which the resource is relevant.'),(15,NULL,1,'rights','Rights','Information about rights held in and over the resource.'),(16,NULL,1,'audience','Audience','A class of entity for whom the resource is intended or useful.'),(17,NULL,1,'alternative','Alternative Title','An alternative name for the resource.'),(18,NULL,1,'tableOfContents','Table Of Contents','A list of subunits of the resource.'),(19,NULL,1,'abstract','Abstract','A summary of the resource.'),(20,NULL,1,'created','Date Created','Date of creation of the resource.'),(21,NULL,1,'valid','Date Valid','Date (often a range) of validity of a resource.'),(22,NULL,1,'available','Date Available','Date (often a range) that the resource became or will become available.'),(23,NULL,1,'issued','Date Issued','Date of formal issuance (e.g., publication) of the resource.'),(24,NULL,1,'modified','Date Modified','Date on which the resource was changed.'),(25,NULL,1,'extent','Extent','The size or duration of the resource.'),(26,NULL,1,'medium','Medium','The material or physical carrier of the resource.'),(27,NULL,1,'isVersionOf','Is Version Of','A related resource of which the described resource is a version, edition, or adaptation.'),(28,NULL,1,'hasVersion','Has Version','A related resource that is a version, edition, or adaptation of the described resource.'),(29,NULL,1,'isReplacedBy','Is Replaced By','A related resource that supplants, displaces, or supersedes the described resource.'),(30,NULL,1,'replaces','Replaces','A related resource that is supplanted, displaced, or superseded by the described resource.'),(31,NULL,1,'isRequiredBy','Is Required By','A related resource that requires the described resource to support its function, delivery, or coherence.'),(32,NULL,1,'requires','Requires','A related resource that is required by the described resource to support its function, delivery, or coherence.'),(33,NULL,1,'isPartOf','Is Part Of','A related resource in which the described resource is physically or logically included.'),(34,NULL,1,'hasPart','Has Part','A related resource that is included either physically or logically in the described resource.'),(35,NULL,1,'isReferencedBy','Is Referenced By','A related resource that references, cites, or otherwise points to the described resource.'),(36,NULL,1,'references','References','A related resource that is referenced, cited, or otherwise pointed to by the described resource.'),(37,NULL,1,'isFormatOf','Is Format Of','A related resource that is substantially the same as the described resource, but in another format.'),(38,NULL,1,'hasFormat','Has Format','A related resource that is substantially the same as the pre-existing described resource, but in another format.'),(39,NULL,1,'conformsTo','Conforms To','An established standard to which the described resource conforms.'),(40,NULL,1,'spatial','Spatial Coverage','Spatial characteristics of the resource.'),(41,NULL,1,'temporal','Temporal Coverage','Temporal characteristics of the resource.'),(42,NULL,1,'mediator','Mediator','An entity that mediates access to the resource and for whom the resource is intended or useful.'),(43,NULL,1,'dateAccepted','Date Accepted','Date of acceptance of the resource.'),(44,NULL,1,'dateCopyrighted','Date Copyrighted','Date of copyright.'),(45,NULL,1,'dateSubmitted','Date Submitted','Date of submission of the resource.'),(46,NULL,1,'educationLevel','Audience Education Level','A class of entity, defined in terms of progression through an educational or training context, for which the described resource is intended.'),(47,NULL,1,'accessRights','Access Rights','Information about who can access the resource or an indication of its security status.'),(48,NULL,1,'bibliographicCitation','Bibliographic Citation','A bibliographic reference for the resource.'),(49,NULL,1,'license','License','A legal document giving official permission to do something with the resource.'),(50,NULL,1,'rightsHolder','Rights Holder','A person or organization owning or managing rights over the resource.'),(51,NULL,1,'provenance','Provenance','A statement of any changes in ownership and custody of the resource since its creation that are significant for its authenticity, integrity, and interpretation.'),(52,NULL,1,'instructionalMethod','Instructional Method','A process, used to engender knowledge, attitudes and skills, that the described resource is designed to support.'),(53,NULL,1,'accrualMethod','Accrual Method','The method by which items are added to a collection.'),(54,NULL,1,'accrualPeriodicity','Accrual Periodicity','The frequency with which items are added to a collection.'),(55,NULL,1,'accrualPolicy','Accrual Policy','The policy governing the addition of items to a collection.'),(56,NULL,3,'affirmedBy','affirmedBy','A legal decision that affirms a ruling.'),(57,NULL,3,'annotates','annotates','Critical or explanatory note for a Document.'),(58,NULL,3,'authorList','list of authors','An ordered list of authors. Normally, this list is seen as a priority list that order authors by importance.'),(59,NULL,3,'citedBy','cited by','Relates a document to another document that cites the\nfirst document.'),(60,NULL,3,'cites','cites','Relates a document to another document that is cited\nby the first document as reference, comment, review, quotation or for\nanother purpose.'),(61,NULL,3,'contributorList','list of contributors','An ordered list of contributors. Normally, this list is seen as a priority list that order contributors by importance.'),(62,NULL,3,'court','court','A court associated with a legal document; for example, that which issues a decision.'),(63,NULL,3,'degree','degree','The thesis degree.'),(64,NULL,3,'director','director','A Film director.'),(65,NULL,3,'distributor','distributor','Distributor of a document or a collection of documents.'),(66,NULL,3,'editor','editor','A person having managerial and sometimes policy-making responsibility for the editorial part of a publishing firm or of a newspaper, magazine, or other publication.'),(67,NULL,3,'editorList','list of editors','An ordered list of editors. Normally, this list is seen as a priority list that order editors by importance.'),(68,NULL,3,'interviewee','interviewee','An agent that is interviewed by another agent.'),(69,NULL,3,'interviewer','interviewer','An agent that interview another agent.'),(70,NULL,3,'issuer','issuer','An entity responsible for issuing often informally published documents such as press releases, reports, etc.'),(71,NULL,3,'organizer','organizer','The organizer of an event; includes conference organizers, but also government agencies or other bodies that are responsible for conducting hearings.'),(72,NULL,3,'owner','owner','Owner of a document or a collection of documents.'),(73,NULL,3,'performer','performer',NULL),(74,NULL,3,'presentedAt','presented at','Relates a document to an event; for example, a paper to a conference.'),(75,NULL,3,'presents','presents','Relates an event to associated documents; for example, conference to a paper.'),(76,NULL,3,'producer','producer','Producer of a document or a collection of documents.'),(77,NULL,3,'recipient','recipient','An agent that receives a communication document.'),(78,NULL,3,'reproducedIn','reproducedIn','The resource in which another resource is reproduced.'),(79,NULL,3,'reversedBy','reversedBy','A legal decision that reverses a ruling.'),(80,NULL,3,'reviewOf','review of','Relates a review document to a reviewed thing (resource, item, etc.).'),(81,NULL,3,'status','status','The publication status of (typically academic) content.'),(82,NULL,3,'subsequentLegalDecision','subsequentLegalDecision','A legal decision on appeal that takes action on a case (affirming it, reversing it, etc.).'),(83,NULL,3,'transcriptOf','transcript of','Relates a document to some transcribed original.'),(84,NULL,3,'translationOf','translation of','Relates a translated document to the original document.'),(85,NULL,3,'translator','translator','A person who translates written document from one language to another.'),(86,NULL,3,'abstract','abstract','A summary of the resource.'),(87,NULL,3,'argued','date argued','The date on which a legal case is argued before a court. Date is of format xsd:date'),(88,NULL,3,'asin','asin',NULL),(89,NULL,3,'chapter','chapter','An chapter number'),(90,NULL,3,'coden','coden',NULL),(91,NULL,3,'content','content','This property is for a plain-text rendering of the content of a Document. While the plain-text content of an entire document could be described by this property.'),(92,NULL,3,'doi','doi',NULL),(93,NULL,3,'eanucc13','eanucc13',NULL),(94,NULL,3,'edition','edition','The name defining a special edition of a document. Normally its a literal value composed of a version number and words.'),(95,NULL,3,'eissn','eissn',NULL),(96,NULL,3,'gtin14','gtin14',NULL),(97,NULL,3,'handle','handle',NULL),(98,NULL,3,'identifier','identifier',NULL),(99,NULL,3,'isbn','isbn',NULL),(100,NULL,3,'isbn10','isbn10',NULL),(101,NULL,3,'isbn13','isbn13',NULL),(102,NULL,3,'issn','issn',NULL),(103,NULL,3,'issue','issue','An issue number'),(104,NULL,3,'lccn','lccn',NULL),(105,NULL,3,'locator','locator','A description (often numeric) that locates an item within a containing document or collection.'),(106,NULL,3,'numPages','number of pages','The number of pages contained in a document'),(107,NULL,3,'numVolumes','number of volumes','The number of volumes contained in a collection of documents (usually a series, periodical, etc.).'),(108,NULL,3,'number','number','A generic item or document number. Not to be confused with issue number.'),(109,NULL,3,'oclcnum','oclcnum',NULL),(110,NULL,3,'pageEnd','page end','Ending page number within a continuous page range.'),(111,NULL,3,'pageStart','page start','Starting page number within a continuous page range.'),(112,NULL,3,'pages','pages','A string of non-contiguous page spans that locate a Document within a Collection. Example: 23-25, 34, 54-56. For continuous page ranges, use the pageStart and pageEnd properties.'),(113,NULL,3,'pmid','pmid',NULL),(114,NULL,3,'prefixName','prefix name','The prefix of a name'),(115,NULL,3,'section','section','A section number'),(116,NULL,3,'shortDescription','shortDescription',NULL),(117,NULL,3,'shortTitle','short title','The abbreviation of a title.'),(118,NULL,3,'sici','sici',NULL),(119,NULL,3,'suffixName','suffix name','The suffix of a name'),(120,NULL,3,'upc','upc',NULL),(121,NULL,3,'uri','uri','Universal Resource Identifier of a document'),(122,NULL,3,'volume','volume','A volume number'),(123,NULL,4,'mbox','personal mailbox','A  personal mailbox, ie. an Internet mailbox associated with exactly one owner, the first owner of this mailbox. This is a \'static inverse functional property\', in that  there is (across time and change) at most one individual that ever has any particular value for foaf:mbox.'),(124,NULL,4,'mbox_sha1sum','sha1sum of a personal mailbox URI name','The sha1sum of the URI of an Internet mailbox associated with exactly one owner, the  first owner of the mailbox.'),(125,NULL,4,'gender','gender','The gender of this Agent (typically but not necessarily \'male\' or \'female\').'),(126,NULL,4,'geekcode','geekcode','A textual geekcode for this person, see http://www.geekcode.com/geek.html'),(127,NULL,4,'dnaChecksum','DNA checksum','A checksum for the DNA of some thing. Joke.'),(128,NULL,4,'sha1','sha1sum (hex)','A sha1sum hash, in hex.'),(129,NULL,4,'based_near','based near','A location that something is based near, for some broadly human notion of near.'),(130,NULL,4,'title','title','Title (Mr, Mrs, Ms, Dr. etc)'),(131,NULL,4,'nick','nickname','A short informal nickname characterising an agent (includes login identifiers, IRC and other chat nicknames).'),(132,NULL,4,'jabberID','jabber ID','A jabber ID for something.'),(133,NULL,4,'aimChatID','AIM chat ID','An AIM chat ID'),(134,NULL,4,'skypeID','Skype ID','A Skype ID'),(135,NULL,4,'icqChatID','ICQ chat ID','An ICQ chat ID'),(136,NULL,4,'yahooChatID','Yahoo chat ID','A Yahoo chat ID'),(137,NULL,4,'msnChatID','MSN chat ID','An MSN chat ID'),(138,NULL,4,'name','name','A name for some thing.'),(139,NULL,4,'firstName','firstName','The first name of a person.'),(140,NULL,4,'lastName','lastName','The last name of a person.'),(141,NULL,4,'givenName','Given name','The given name of some person.'),(142,NULL,4,'givenname','Given name','The given name of some person.'),(143,NULL,4,'surname','Surname','The surname of some person.'),(144,NULL,4,'family_name','family_name','The family name of some person.'),(145,NULL,4,'familyName','familyName','The family name of some person.'),(146,NULL,4,'phone','phone','A phone,  specified using fully qualified tel: URI scheme (refs: http://www.w3.org/Addressing/schemes.html#tel).'),(147,NULL,4,'homepage','homepage','A homepage for some thing.'),(148,NULL,4,'weblog','weblog','A weblog of some thing (whether person, group, company etc.).'),(149,NULL,4,'openid','openid','An OpenID for an Agent.'),(150,NULL,4,'tipjar','tipjar','A tipjar document for this agent, describing means for payment and reward.'),(151,NULL,4,'plan','plan','A .plan comment, in the tradition of finger and \'.plan\' files.'),(152,NULL,4,'made','made','Something that was made by this agent.'),(153,NULL,4,'maker','maker','An agent that  made this thing.'),(154,NULL,4,'img','image','An image that can be used to represent some thing (ie. those depictions which are particularly representative of something, eg. one\'s photo on a homepage).'),(155,NULL,4,'depiction','depiction','A depiction of some thing.'),(156,NULL,4,'depicts','depicts','A thing depicted in this representation.'),(157,NULL,4,'thumbnail','thumbnail','A derived thumbnail image.'),(158,NULL,4,'myersBriggs','myersBriggs','A Myers Briggs (MBTI) personality classification.'),(159,NULL,4,'workplaceHomepage','workplace homepage','A workplace homepage of some person; the homepage of an organization they work for.'),(160,NULL,4,'workInfoHomepage','work info homepage','A work info homepage of some person; a page about their work for some organization.'),(161,NULL,4,'schoolHomepage','schoolHomepage','A homepage of a school attended by the person.'),(162,NULL,4,'knows','knows','A person known by this person (indicating some level of reciprocated interaction between the parties).'),(163,NULL,4,'interest','interest','A page about a topic of interest to this person.'),(164,NULL,4,'topic_interest','topic_interest','A thing of interest to this person.'),(165,NULL,4,'publications','publications','A link to the publications of this person.'),(166,NULL,4,'currentProject','current project','A current project this person works on.'),(167,NULL,4,'pastProject','past project','A project this person has previously worked on.'),(168,NULL,4,'fundedBy','funded by','An organization funding a project or person.'),(169,NULL,4,'logo','logo','A logo representing some thing.'),(170,NULL,4,'topic','topic','A topic of some page or document.'),(171,NULL,4,'primaryTopic','primary topic','The primary topic of some page or document.'),(172,NULL,4,'focus','focus','The underlying or \'focal\' entity associated with some SKOS-described concept.'),(173,NULL,4,'isPrimaryTopicOf','is primary topic of','A document that this thing is the primary topic of.'),(174,NULL,4,'page','page','A page or document about this thing.'),(175,NULL,4,'theme','theme','A theme.'),(176,NULL,4,'account','account','Indicates an account held by this agent.'),(177,NULL,4,'holdsAccount','account','Indicates an account held by this agent.'),(178,NULL,4,'accountServiceHomepage','account service homepage','Indicates a homepage of the service provide for this online account.'),(179,NULL,4,'accountName','account name','Indicates the name (identifier) associated with this online account.'),(180,NULL,4,'member','member','Indicates a member of a Group'),(181,NULL,4,'membershipClass','membershipClass','Indicates the class of individuals that are a member of a Group'),(182,NULL,4,'birthday','birthday','The birthday of this Agent, represented in mm-dd string form, eg. \'12-31\'.'),(183,NULL,4,'age','age','The age in years of some agent.'),(184,NULL,4,'status','status','A string expressing what the user is happy for the general public (normally) to know about their current activity.'),(185,1,5,'annotationService','annotation service','The object of the relationship is the end point of a service that conforms to the annotation-protocol, and it may be associated with any resource.  The expectation of asserting the relationship is that the object is the preferred service for maintaining annotations about the subject resource, according to the publisher of the relationship.\n\n  This relationship is intended to be used both within Linked Data descriptions and as the  rel  type of a Link, via HTTP Link Headers rfc5988 for binary resources and in HTML <link> elements.  For more information about these, please see the Annotation Protocol specification annotation-protocol.\n  '),(186,1,5,'bodyValue','body value','The object of the predicate is a plain text string to be used as the content of the body of the Annotation.  The value MUST be an  xsd:string  and that data type MUST NOT be expressed in the serialization. Note that language MUST NOT be associated with the value either as a language tag, as that is only available for  rdf:langString .\n  '),(187,1,5,'cachedSource','cached source','A object of the relationship is a copy of the Source resource\'s representation, appropriate for the Annotation.'),(188,1,5,'canonical','canonical','A object of the relationship is the canonical IRI that can always be used to deduplicate the Annotation, regardless of the current IRI used to access the representation.'),(189,1,5,'end','end','The end property is used to convey the 0-based index of the end position of a range of content.'),(190,1,5,'exact','exact','The object of the predicate is a copy of the text which is being selected, after normalization.'),(191,1,5,'hasBody','has body','The object of the relationship is a resource that is a body of the Annotation.'),(192,1,5,'hasEndSelector','has end selector','The relationship between a RangeSelector and the Selector that describes the end position of the range. '),(193,1,5,'hasPurpose','has purpose','The purpose served by the resource in the Annotation.'),(194,1,5,'hasScope','has scope','The scope or context in which the resource is used within the Annotation.'),(195,1,5,'hasSelector','has selector','The object of the relationship is a Selector that describes the segment or region of interest within the source resource.  Please note that the domain ( oa:ResourceSelection ) is not used directly in the Web Annotation model.'),(196,1,5,'hasSource','has source','The resource that the ResourceSelection, or its subclass SpecificResource, is refined from, or more specific than. Please note that the domain ( oa:ResourceSelection ) is not used directly in the Web Annotation model.'),(197,1,5,'hasStartSelector','has start selector','The relationship between a RangeSelector and the Selector that describes the start position of the range. '),(198,1,5,'hasState','has state','The relationship between the ResourceSelection, or its subclass SpecificResource, and a State resource. Please note that the domain ( oa:ResourceSelection ) is not used directly in the Web Annotation model.'),(199,1,5,'hasTarget','has target','The relationship between an Annotation and its Target.'),(200,1,5,'motivatedBy','motivated by','The relationship between an Annotation and a Motivation that describes the reason for the Annotation\'s creation.'),(201,1,5,'prefix','prefix','The object of the property is a snippet of content that occurs immediately before the content which is being selected by the Selector.'),(202,1,5,'processingLanguage','processing language','The object of the property is the language that should be used for textual processing algorithms when dealing with the content of the resource, including hyphenation, line breaking, which font to use for rendering and so forth.  The value must follow the recommendations of BCP47.'),(203,1,5,'refinedBy','refined by','The relationship between a Selector and another Selector or a State and a Selector or State that should be applied to the results of the first to refine the processing of the source resource. '),(204,1,5,'renderedVia','rendered via','A system that was used by the application that created the Annotation to render the resource.'),(205,1,5,'sourceDate','source date','The timestamp at which the Source resource should be interpreted as being applicable to the Annotation.'),(206,1,5,'sourceDateEnd','source date end','The end timestamp of the interval over which the Source resource should be interpreted as being applicable to the Annotation.'),(207,1,5,'sourceDateStart','source date start','The start timestamp of the interval over which the Source resource should be interpreted as being applicable to the Annotation.'),(208,1,5,'start','start','The start position in a 0-based index at which a range of content is selected from the data in the source resource.'),(209,1,5,'styleClass','style class','The name of the class used in the CSS description referenced from the Annotation that should be applied to the Specific Resource.'),(210,1,5,'styledBy','styled by','A reference to a Stylesheet that should be used to apply styles to the Annotation rendering.'),(211,1,5,'suffix','suffix','The snippet of text that occurs immediately after the text which is being selected.'),(212,1,5,'textDirection','text direction','The direction of the text of the subject resource. There MUST only be one text direction associated with any given resource.'),(213,1,5,'via','via','A object of the relationship is a resource from which the source resource was retrieved by the providing system.'),(214,1,6,'type','type','The subject is an instance of a class.'),(215,1,6,'subject','subject','The subject of the subject RDF statement.'),(216,1,6,'predicate','predicate','The predicate of the subject RDF statement.'),(217,1,6,'object','object','The object of the subject RDF statement.'),(218,1,6,'value','value','Idiomatic property used for structured values.'),(219,1,6,'first','first','The first item in the subject RDF list.'),(220,1,6,'rest','rest','The rest of the subject RDF list after the first item.'),(221,1,7,'access','Access','Define an access to the resource.'),(222,1,7,'featured','Featured','Mark the resource as a featured one as soon as a value is set, whatever it is.'),(223,1,7,'new','New','Mark the resource as a new one as soon as a value is set, whatever it is.'),(224,1,7,'reserved','Reserved','Define the resource as a restricted access one as soon a value is set, whatever it is.'),(225,1,7,'selected','Selected','Mark the resource as a selected one as soon as a value is set, whatever it is.'),(226,1,7,'category','Category','A topic that can be used for some purposes.'),(227,1,7,'collection','Collection','A way to group resources.'),(228,1,7,'set','Set','A set to group resources together.'),(229,1,7,'subject','Subject','A subject to describe the resource.'),(230,1,7,'tag','Tag','Tag that can be used for some purposes or for upgrade from Omeka Classic.'),(231,1,7,'theme','Theme','A domain that can be used for some purposes.'),(232,1,7,'type','Type','A type that can be used for some purposes.'),(233,1,7,'coordinates','Coordinates','Numerical coordinates related to the resource, generaly the geographic position.'),(234,1,7,'data','Data','Any data that can be used for any purpose.'),(235,1,7,'start','Start','A start related to the resource, for example the start of an embargo.'),(236,1,7,'end','End','A end related to the resource, for example the end of an embargo.'),(237,1,7,'location','Location','A location related to the resource, for example the place of publication.'),(238,1,7,'note','Note','A specific or generic information on a resource, generally for internal purposes.'),(239,1,7,'number','Number','A number related to the resource.'),(240,1,7,'rank','Rank','A rank or a position related to the resource.'),(241,1,7,'status','Status','The status of the resource, generally for internal purposes.'),(242,1,8,'hasStory','has a story',NULL),(243,1,8,'hasActor','has an actor',NULL),(244,1,8,'hasObjet','has an objet',NULL),(245,1,8,'hasEvent','has an event',NULL),(246,1,8,'hasAffect','has an affect',NULL),(247,1,8,'hasPlace','has a place',NULL),(248,1,8,'hasScenario','has a scenario',NULL),(249,1,8,'hasWorld','has a world',NULL),(250,1,8,'hasFonction','has a fonction',NULL),(251,1,8,'hasParam','has a parameter',NULL),(252,1,8,'hasInitialCondition','has a initial condition',NULL),(253,1,8,'order','Order',NULL),(254,1,8,'hasEventAfterValid','has a event after validation',NULL),(255,1,8,'hasEventAfterFailure','has a event after failure',NULL);
/*!40000 ALTER TABLE `property` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `resource`
--

DROP TABLE IF EXISTS `resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) DEFAULT NULL,
  `resource_class_id` int(11) DEFAULT NULL,
  `resource_template_id` int(11) DEFAULT NULL,
  `thumbnail_id` int(11) DEFAULT NULL,
  `title` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `resource_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_BC91F4167E3C61F9` (`owner_id`),
  KEY `IDX_BC91F416448CC1BD` (`resource_class_id`),
  KEY `IDX_BC91F41616131EA` (`resource_template_id`),
  KEY `IDX_BC91F416FDFF2E92` (`thumbnail_id`),
  KEY `title` (`title`(190)),
  CONSTRAINT `FK_BC91F41616131EA` FOREIGN KEY (`resource_template_id`) REFERENCES `resource_template` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_BC91F416448CC1BD` FOREIGN KEY (`resource_class_id`) REFERENCES `resource_class` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_BC91F4167E3C61F9` FOREIGN KEY (`owner_id`) REFERENCES `user` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_BC91F416FDFF2E92` FOREIGN KEY (`thumbnail_id`) REFERENCES `asset` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resource`
--

LOCK TABLES `resource` WRITE;
/*!40000 ALTER TABLE `resource` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `resource` VALUES (1,1,135,3,NULL,'Tom & Jerry pursuit',1,'2024-03-01 15:04:47','2024-03-01 15:04:47','Omeka\\Entity\\Item'),(2,7,135,3,NULL,'A future with artificial intelligence',1,'2024-03-08 01:30:36','2024-03-08 03:41:15','Omeka\\Entity\\Item');
/*!40000 ALTER TABLE `resource` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `resource_class`
--

DROP TABLE IF EXISTS `resource_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resource_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) DEFAULT NULL,
  `vocabulary_id` int(11) NOT NULL,
  `local_name` varchar(190) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_C6F063ADAD0E05F6623C14D5` (`vocabulary_id`,`local_name`),
  KEY `IDX_C6F063AD7E3C61F9` (`owner_id`),
  KEY `IDX_C6F063ADAD0E05F6` (`vocabulary_id`),
  CONSTRAINT `FK_C6F063AD7E3C61F9` FOREIGN KEY (`owner_id`) REFERENCES `user` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_C6F063ADAD0E05F6` FOREIGN KEY (`vocabulary_id`) REFERENCES `vocabulary` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resource_class`
--

LOCK TABLES `resource_class` WRITE;
/*!40000 ALTER TABLE `resource_class` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `resource_class` VALUES (1,NULL,1,'Agent','Agent','A resource that acts or has the power to act.'),(2,NULL,1,'AgentClass','Agent Class','A group of agents.'),(3,NULL,1,'BibliographicResource','Bibliographic Resource','A book, article, or other documentary resource.'),(4,NULL,1,'FileFormat','File Format','A digital resource format.'),(5,NULL,1,'Frequency','Frequency','A rate at which something recurs.'),(6,NULL,1,'Jurisdiction','Jurisdiction','The extent or range of judicial, law enforcement, or other authority.'),(7,NULL,1,'LicenseDocument','License Document','A legal document giving official permission to do something with a Resource.'),(8,NULL,1,'LinguisticSystem','Linguistic System','A system of signs, symbols, sounds, gestures, or rules used in communication.'),(9,NULL,1,'Location','Location','A spatial region or named place.'),(10,NULL,1,'LocationPeriodOrJurisdiction','Location, Period, or Jurisdiction','A location, period of time, or jurisdiction.'),(11,NULL,1,'MediaType','Media Type','A file format or physical medium.'),(12,NULL,1,'MediaTypeOrExtent','Media Type or Extent','A media type or extent.'),(13,NULL,1,'MethodOfInstruction','Method of Instruction','A process that is used to engender knowledge, attitudes, and skills.'),(14,NULL,1,'MethodOfAccrual','Method of Accrual','A method by which resources are added to a collection.'),(15,NULL,1,'PeriodOfTime','Period of Time','An interval of time that is named or defined by its start and end dates.'),(16,NULL,1,'PhysicalMedium','Physical Medium','A physical material or carrier.'),(17,NULL,1,'PhysicalResource','Physical Resource','A material thing.'),(18,NULL,1,'Policy','Policy','A plan or course of action by an authority, intended to influence and determine decisions, actions, and other matters.'),(19,NULL,1,'ProvenanceStatement','Provenance Statement','A statement of any changes in ownership and custody of a resource since its creation that are significant for its authenticity, integrity, and interpretation.'),(20,NULL,1,'RightsStatement','Rights Statement','A statement about the intellectual property rights (IPR) held in or over a Resource, a legal document giving official permission to do something with a resource, or a statement about access rights.'),(21,NULL,1,'SizeOrDuration','Size or Duration','A dimension or extent, or a time taken to play or execute.'),(22,NULL,1,'Standard','Standard','A basis for comparison; a reference point against which other things can be evaluated.'),(23,NULL,2,'Collection','Collection','An aggregation of resources.'),(24,NULL,2,'Dataset','Dataset','Data encoded in a defined structure.'),(25,NULL,2,'Event','Event','A non-persistent, time-based occurrence.'),(26,NULL,2,'Image','Image','A visual representation other than text.'),(27,NULL,2,'InteractiveResource','Interactive Resource','A resource requiring interaction from the user to be understood, executed, or experienced.'),(28,NULL,2,'Service','Service','A system that provides one or more functions.'),(29,NULL,2,'Software','Software','A computer program in source or compiled form.'),(30,NULL,2,'Sound','Sound','A resource primarily intended to be heard.'),(31,NULL,2,'Text','Text','A resource consisting primarily of words for reading.'),(32,NULL,2,'PhysicalObject','Physical Object','An inanimate, three-dimensional object or substance.'),(33,NULL,2,'StillImage','Still Image','A static visual representation.'),(34,NULL,2,'MovingImage','Moving Image','A series of visual representations imparting an impression of motion when shown in succession.'),(35,NULL,3,'AcademicArticle','Academic Article','A scholarly academic article, typically published in a journal.'),(36,NULL,3,'Article','Article','A written composition in prose, usually nonfiction, on a specific topic, forming an independent part of a book or other publication, as a newspaper or magazine.'),(37,NULL,3,'AudioDocument','audio document','An audio document; aka record.'),(38,NULL,3,'AudioVisualDocument','audio-visual document','An audio-visual document; film, video, and so forth.'),(39,NULL,3,'Bill','Bill','Draft legislation presented for discussion to a legal body.'),(40,NULL,3,'Book','Book','A written or printed work of fiction or nonfiction, usually on sheets of paper fastened or bound together within covers.'),(41,NULL,3,'BookSection','Book Section','A section of a book.'),(42,NULL,3,'Brief','Brief','A written argument submitted to a court.'),(43,NULL,3,'Chapter','Chapter','A chapter of a book.'),(44,NULL,3,'Code','Code','A collection of statutes.'),(45,NULL,3,'CollectedDocument','Collected Document','A document that simultaneously contains other documents.'),(46,NULL,3,'Collection','Collection','A collection of Documents or Collections'),(47,NULL,3,'Conference','Conference','A meeting for consultation or discussion.'),(48,NULL,3,'CourtReporter','Court Reporter','A collection of legal cases.'),(49,NULL,3,'Document','Document','A document (noun) is a bounded physical representation of body of information designed with the capacity (and usually intent) to communicate. A document may manifest symbolic, diagrammatic or sensory-representational information.'),(50,NULL,3,'DocumentPart','document part','a distinct part of a larger document or collected document.'),(51,NULL,3,'DocumentStatus','Document Status','The status of the publication of a document.'),(52,NULL,3,'EditedBook','Edited Book','An edited book.'),(53,NULL,3,'Email','EMail','A written communication addressed to a person or organization and transmitted electronically.'),(54,NULL,3,'Event','Event',NULL),(55,NULL,3,'Excerpt','Excerpt','A passage selected from a larger work.'),(56,NULL,3,'Film','Film','aka movie.'),(57,NULL,3,'Hearing','Hearing','An instance or a session in which testimony and arguments are presented, esp. before an official, as a judge in a lawsuit.'),(58,NULL,3,'Image','Image','A document that presents visual or diagrammatic information.'),(59,NULL,3,'Interview','Interview','A formalized discussion between two or more people.'),(60,NULL,3,'Issue','Issue','something that is printed or published and distributed, esp. a given number of a periodical'),(61,NULL,3,'Journal','Journal','A periodical of scholarly journal Articles.'),(62,NULL,3,'LegalCaseDocument','Legal Case Document','A document accompanying a legal case.'),(63,NULL,3,'LegalDecision','Decision','A document containing an authoritative determination (as a decree or judgment) made after consideration of facts or law.'),(64,NULL,3,'LegalDocument','Legal Document','A legal document; for example, a court decision, a brief, and so forth.'),(65,NULL,3,'Legislation','Legislation','A legal document proposing or enacting a law or a group of laws.'),(66,NULL,3,'Letter','Letter','A written or printed communication addressed to a person or organization and usually transmitted by mail.'),(67,NULL,3,'Magazine','Magazine','A periodical of magazine Articles. A magazine is a publication that is issued periodically, usually bound in a paper cover, and typically contains essays, stories, poems, etc., by many writers, and often photographs and drawings, frequently specializing in a particular subject or area, as hobbies, news, or sports.'),(68,NULL,3,'Manual','Manual','A small reference book, especially one giving instructions.'),(69,NULL,3,'Manuscript','Manuscript','An unpublished Document, which may also be submitted to a publisher for publication.'),(70,NULL,3,'Map','Map','A graphical depiction of geographic features.'),(71,NULL,3,'MultiVolumeBook','Multivolume Book','A loose, thematic, collection of Documents, often Books.'),(72,NULL,3,'Newspaper','Newspaper','A periodical of documents, usually issued daily or weekly, containing current news, editorials, feature articles, and usually advertising.'),(73,NULL,3,'Note','Note','Notes or annotations about a resource.'),(74,NULL,3,'Patent','Patent','A document describing the exclusive right granted by a government to an inventor to manufacture, use, or sell an invention for a certain number of years.'),(75,NULL,3,'Performance','Performance','A public performance.'),(76,NULL,3,'Periodical','Periodical','A group of related documents issued at regular intervals.'),(77,NULL,3,'PersonalCommunication','Personal Communication','A communication between an agent and one or more specific recipients.'),(78,NULL,3,'PersonalCommunicationDocument','Personal Communication Document','A personal communication manifested in some document.'),(79,NULL,3,'Proceedings','Proceedings','A compilation of documents published from an event, such as a conference.'),(80,NULL,3,'Quote','Quote','An excerpted collection of words.'),(81,NULL,3,'ReferenceSource','Reference Source','A document that presents authoritative reference information, such as a dictionary or encylopedia .'),(82,NULL,3,'Report','Report','A document describing an account or statement describing in detail an event, situation, or the like, usually as the result of observation, inquiry, etc..'),(83,NULL,3,'Series','Series','A loose, thematic, collection of Documents, often Books.'),(84,NULL,3,'Slide','Slide','A slide in a slideshow'),(85,NULL,3,'Slideshow','Slideshow','A presentation of a series of slides, usually presented in front of an audience with written text and images.'),(86,NULL,3,'Standard','Standard','A document describing a standard'),(87,NULL,3,'Statute','Statute','A bill enacted into law.'),(88,NULL,3,'Thesis','Thesis','A document created to summarize research findings associated with the completion of an academic degree.'),(89,NULL,3,'ThesisDegree','Thesis degree','The academic degree of a Thesis'),(90,NULL,3,'Webpage','Webpage','A web page is an online document available (at least initially) on the world wide web. A web page is written first and foremost to appear on the web, as distinct from other online resources such as books, manuscripts or audio documents which use the web primarily as a distribution mechanism alongside other more traditional methods such as print.'),(91,NULL,3,'Website','Website','A group of Webpages accessible on the Web.'),(92,NULL,3,'Workshop','Workshop','A seminar, discussion group, or the like, that emphasizes zxchange of ideas and the demonstration and application of techniques, skills, etc.'),(93,NULL,4,'LabelProperty','Label Property','A foaf:LabelProperty is any RDF property with texual values that serve as labels.'),(94,NULL,4,'Person','Person','A person.'),(95,NULL,4,'Document','Document','A document.'),(96,NULL,4,'Organization','Organization','An organization.'),(97,NULL,4,'Group','Group','A class of Agents.'),(98,NULL,4,'Agent','Agent','An agent (eg. person, group, software or physical artifact).'),(99,NULL,4,'Project','Project','A project (a collective endeavour of some kind).'),(100,NULL,4,'Image','Image','An image.'),(101,NULL,4,'PersonalProfileDocument','PersonalProfileDocument','A personal profile RDF document.'),(102,NULL,4,'OnlineAccount','Online Account','An online account.'),(103,NULL,4,'OnlineGamingAccount','Online Gaming Account','An online gaming account.'),(104,NULL,4,'OnlineEcommerceAccount','Online E-commerce Account','An online e-commerce account.'),(105,NULL,4,'OnlineChatAccount','Online Chat Account','An online chat account.'),(106,1,5,'Annotation','Annotation','The class for Web Annotations.'),(107,1,5,'Choice','Choice','A subClass of  as:OrderedCollection  that conveys to a consuming application that it should select one of the resources in the  as:items  list to use, rather than all of them.  This is typically used to provide a choice of resources to render to the user, based on further supplied properties.  If the consuming application cannot determine the user\'s preference, then it should use the first in the list.'),(108,1,5,'CssSelector','Css selector','A CssSelector describes a Segment of interest in a representation that conforms to the Document Object Model through the use of the CSS selector specification.'),(109,1,5,'CssStyle','Css style','A resource which describes styles for resources participating in the Annotation using CSS.'),(110,1,5,'DataPositionSelector','Data position selector','DataPositionSelector describes a range of data by recording the start and end positions of the selection in the stream. Position 0 would be immediately before the first byte, position 1 would be immediately before the second byte, and so on. The start byte is thus included in the list, but the end byte is not.'),(111,1,5,'Direction','Direction','A class to encapsulate the different text directions that a textual resource might take.  It is not used directly in the Annotation Model, only its three instances.'),(112,1,5,'FragmentSelector','Fragment selector','The FragmentSelector class is used to record the segment of a representation using the IRI fragment specification defined by the representation\'s media type.'),(113,1,5,'HttpRequestState','Http request state','The HttpRequestState class is used to record the HTTP request headers that a client SHOULD use to request the correct representation from the resource. '),(114,1,5,'Motivation','Motivation','The Motivation class is used to record the user\'s intent or motivation for the creation of the Annotation, or the inclusion of the body or target, that it is associated with.'),(115,1,5,'RangeSelector','Range selector','A Range Selector can be used to identify the beginning and the end of the selection by using other Selectors. The selection consists of everything from the beginning of the starting selector through to the beginning of the ending selector, but not including it.'),(116,1,5,'ResourceSelection','Resource selection','Instances of the ResourceSelection class identify part (described by an oa:Selector) of another resource (referenced with oa:hasSource), possibly from a particular representation of a resource (described by an oa:State). Please note that ResourceSelection is not used directly in the Web Annotation model, but is provided as a separate class for further application profiles to use, separate from oa:SpecificResource which has many Annotation specific features.'),(117,1,5,'Selector','Selector','A resource which describes the segment of interest in a representation of a Source resource, indicated with oa:hasSelector from the Specific Resource. This class is not used directly in the Annotation model, only its subclasses.'),(118,1,5,'SpecificResource','Specific resource','Instances of the SpecificResource class identify part of another resource (referenced with oa:hasSource), a particular representation of a resource, a resource with styling hints for renders, or any combination of these, as used within an Annotation.'),(119,1,5,'State','State','A State describes the intended state of a resource as applied to the particular Annotation, and thus provides the information needed to retrieve the correct representation of that resource.'),(120,1,5,'Style','Style','A Style describes the intended styling of a resource as applied to the particular Annotation, and thus provides the information to ensure that rendering is consistent across implementations.'),(121,1,5,'SvgSelector','Svg selector','An SvgSelector defines an area through the use of the Scalable Vector Graphics [SVG] standard. This allows the user to select a non-rectangular area of the content, such as a circle or polygon by describing the region using SVG. The SVG may be either embedded within the Annotation or referenced as an External Resource.'),(122,1,5,'TextPositionSelector','Text position selector','The TextPositionSelector describes a range of text by recording the start and end positions of the selection in the stream. Position 0 would be immediately before the first character, position 1 would be immediately before the second character, and so on.'),(123,1,5,'TextQuoteSelector','Text quote selector','The TextQuoteSelector describes a range of text by copying it, and including some of the text immediately before (a prefix) and after (a suffix) it to distinguish between multiple copies of the same sequence of characters.'),(124,1,5,'TextualBody','Textual body',''),(125,1,5,'TimeState','Time state','A TimeState records the time at which the resource\'s state is appropriate for the Annotation, typically the time that the Annotation was created and/or a link to a persistent copy of the current version.'),(126,1,5,'XPathSelector','XPath selector',' An XPathSelector is used to select elements and content within a resource that supports the Document Object Model via a specified XPath value.'),(127,1,6,'Property','Property','The class of RDF properties.'),(128,1,6,'Statement','Statement','The class of RDF statements.'),(129,1,6,'Bag','Bag','The class of unordered containers.'),(130,1,6,'Seq','Seq','The class of ordered containers.'),(131,1,6,'Alt','Alt','The class of containers of alternatives.'),(132,1,6,'List','List','The class of RDF Lists.'),(133,1,8,'world','world',NULL),(134,1,8,'scenario','scenario',NULL),(135,1,8,'story','story',NULL),(136,1,8,'actor','actor',NULL),(137,1,8,'place','place',NULL),(138,1,8,'event','event',NULL),(139,1,8,'affect','affect',NULL),(140,1,8,'object','object',NULL);
/*!40000 ALTER TABLE `resource_class` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `resource_template`
--

DROP TABLE IF EXISTS `resource_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resource_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) DEFAULT NULL,
  `resource_class_id` int(11) DEFAULT NULL,
  `title_property_id` int(11) DEFAULT NULL,
  `description_property_id` int(11) DEFAULT NULL,
  `label` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_39ECD52EEA750E8` (`label`),
  KEY `IDX_39ECD52E7E3C61F9` (`owner_id`),
  KEY `IDX_39ECD52E448CC1BD` (`resource_class_id`),
  KEY `IDX_39ECD52E724734A3` (`title_property_id`),
  KEY `IDX_39ECD52EB84E0D1D` (`description_property_id`),
  CONSTRAINT `FK_39ECD52E448CC1BD` FOREIGN KEY (`resource_class_id`) REFERENCES `resource_class` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_39ECD52E724734A3` FOREIGN KEY (`title_property_id`) REFERENCES `property` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_39ECD52E7E3C61F9` FOREIGN KEY (`owner_id`) REFERENCES `user` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_39ECD52EB84E0D1D` FOREIGN KEY (`description_property_id`) REFERENCES `property` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resource_template`
--

LOCK TABLES `resource_template` WRITE;
/*!40000 ALTER TABLE `resource_template` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `resource_template` VALUES (1,NULL,NULL,NULL,NULL,'Base Resource'),(2,1,106,NULL,NULL,'Annotation'),(3,1,135,NULL,NULL,'Story');
/*!40000 ALTER TABLE `resource_template` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `resource_template_property`
--

DROP TABLE IF EXISTS `resource_template_property`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resource_template_property` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_template_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `alternate_label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alternate_comment` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `data_type` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '(DC2Type:json_array)',
  `is_required` tinyint(1) NOT NULL,
  `is_private` tinyint(1) NOT NULL,
  `default_lang` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_4689E2F116131EA549213EC` (`resource_template_id`,`property_id`),
  KEY `IDX_4689E2F116131EA` (`resource_template_id`),
  KEY `IDX_4689E2F1549213EC` (`property_id`),
  CONSTRAINT `FK_4689E2F116131EA` FOREIGN KEY (`resource_template_id`) REFERENCES `resource_template` (`id`),
  CONSTRAINT `FK_4689E2F1549213EC` FOREIGN KEY (`property_id`) REFERENCES `property` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resource_template_property`
--

LOCK TABLES `resource_template_property` WRITE;
/*!40000 ALTER TABLE `resource_template_property` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `resource_template_property` VALUES (1,1,1,NULL,NULL,1,NULL,0,0,NULL),(2,1,15,NULL,NULL,2,NULL,0,0,NULL),(3,1,8,NULL,NULL,3,NULL,0,0,NULL),(4,1,2,NULL,NULL,4,NULL,0,0,NULL),(5,1,7,NULL,NULL,5,NULL,0,0,NULL),(6,1,4,NULL,NULL,6,NULL,0,0,NULL),(7,1,9,NULL,NULL,7,NULL,0,0,NULL),(8,1,12,NULL,NULL,8,NULL,0,0,NULL),(9,1,40,'Place',NULL,9,NULL,0,0,NULL),(10,1,5,NULL,NULL,10,NULL,0,0,NULL),(11,1,17,NULL,NULL,11,NULL,0,0,NULL),(12,1,6,NULL,NULL,12,NULL,0,0,NULL),(13,1,25,NULL,NULL,13,NULL,0,0,NULL),(14,1,10,NULL,NULL,14,NULL,0,0,NULL),(15,1,13,NULL,NULL,15,NULL,0,0,NULL),(16,1,29,NULL,NULL,16,NULL,0,0,NULL),(17,1,30,NULL,NULL,17,NULL,0,0,NULL),(18,1,50,NULL,NULL,18,NULL,0,0,NULL),(19,1,3,NULL,NULL,19,NULL,0,0,NULL),(20,1,41,NULL,NULL,20,NULL,0,0,NULL),(21,2,200,'Motivated by',NULL,1,'[\"customvocab:4\"]',0,0,NULL),(22,2,218,'Value','May be used for body textual content and/or json/xml/svg, etc. target selector.',2,'[\"literal\"]',0,0,NULL),(23,2,193,'Has purpose',NULL,3,'[\"customvocab:1\"]',0,0,NULL),(24,2,12,NULL,'Language of the textual body.',4,'[\"literal\"]',0,0,NULL),(25,2,196,'Has source',NULL,5,'[\"resource\"]',0,0,NULL),(26,2,214,'Rdf type','The type of the selector, if any.',6,'[\"customvocab:3\"]',0,0,NULL),(27,2,9,NULL,'The format of the selector, if any',7,'[\"customvocab:2\"]',0,0,NULL),(28,3,1,NULL,NULL,1,NULL,0,0,NULL),(29,3,4,NULL,NULL,2,NULL,0,0,NULL),(30,3,243,NULL,'class=genstory:actor',3,NULL,0,0,NULL),(31,3,244,NULL,'class=genstory:object',4,NULL,0,0,NULL),(32,3,247,NULL,'class=genstory:place',5,NULL,0,0,NULL),(33,3,246,NULL,'class=genstory:affect',6,NULL,0,0,NULL),(34,3,245,NULL,'class=genstory:event',7,NULL,0,0,NULL),(35,3,242,NULL,'class=genstory:story',8,NULL,0,0,NULL);
/*!40000 ALTER TABLE `resource_template_property` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session` (
  `id` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` longblob NOT NULL,
  `modified` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `session` VALUES ('0029b21d61bb9be1ad7e033a2a02dc50',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393336353138342E3039393738373B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223030323962323164363162623962653161643765303333613261303264633530223B7D7D,1709365184),('03e21d55237a118840941860acca5e4f',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836333332312E3432393535353B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223033653231643535323337613131383834303934313836306163636135653466223B7D7D,1709863321),('0a25d32c547d4ce5a2afacbb3fb027b0',0x5F5F4C616D696E61737C613A353A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730383039373636302E3030313832363B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226237666264303266386237323862303265383165393331303366383433623031223B7D733A34323A224C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730383039383237303B7D733A34343A224C616D696E61735F56616C696461746F725F437372665F73616C745F636F6E6669726D666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730383039383330373B7D733A33323A224C616D696E61735F56616C696461746F725F437372665F73616C745F63737266223B613A313A7B733A363A22455850495245223B693A313730383039383330343B7D7D72656469726563745F75726C7C733A33353A2268747470733A2F2F7464637732342E67656E657261746575722E6172742F61646D696E223B4C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A31313A7B733A33323A223962343638393235366433613530623063373434386631343336363835616237223B733A33323A226366623735396638333365666536396334633933326534313362303564363232223B733A33323A223838363063303635633664346233336232303530653238633437383563333264223B733A33323A226436363238336234373130313838383332333861666166633233636266663534223B733A33323A226663313330366137393138376262303731356533303033643938366534616633223B733A33323A226439313738656262393461636666356463303330626136633431633966393231223B733A33323A223162393066363331633535626530313634613637356435393663323535356662223B733A33323A223837316261633439396565653338366639323565626362373930373062626237223B733A33323A226563656261383063386134313433326234333636393035376566663732666563223B733A33323A223434386332323538613865316432373139363662316637373862333934346262223B733A33323A226166636233613838336433323862643665353935616462656366396664323136223B733A33323A226465633337346462633362313831336463376663663032343964643061666362223B733A33323A223565383332353934616634653164616163633061356666303136356665646436223B733A33323A223964326262356562623762373065616538383561326261636633636337323639223B733A33323A226561613239653965323465363735353738613236303832346534303266353630223B733A33323A223937666266393933333237313536633561393032623830613339333365373537223B733A33323A223465313465653166653764333533613136306461633362306236363437613633223B733A33323A223866663664373066323134326239343830633339346137383764363138363435223B733A33323A223537316138386565366638303166333337376137313535653938646335313930223B733A33323A226635306363386631633435616231353062386630333938376563613166613334223B733A33323A223663343938663832383264336430663566613663386661323739646539366436223B733A33323A223332323539376233343334393363343134383231326138313034663161366564223B7D733A343A2268617368223B733A36353A2233323235393762333433343933633431343832313261383130346631613665642D3663343938663832383264336430663566613663386661323739646539366436223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4F6D656B614D657373656E6765727C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A303A7B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F417574687C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A313A7B733A373A2273746F72616765223B693A393B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F636F6E6669726D666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A343A7B733A33323A223934633464643136633063306137353536313361626133346438346638383331223B733A33323A223761343637363162663365346366313764323265346366353663613438626233223B733A33323A226164386536646165376665393661653833653236343436626461643637626664223B733A33323A223163396662353262363962363661343731623637303837306430383934343165223B733A33323A226562363066386663333330363765376463383931616333363537333532613437223B733A33323A223461643263643561323738363764396133383439363063626439366238393764223B733A33323A223637303964623733363665623735383737303836633861376265633734653036223B733A33323A223737623966626262643535663238373066326635643461643536343537663531223B7D733A343A2268617368223B733A36353A2237376239666262626435356632383730663266356434616435363435376635312D3637303964623733363665623735383737303836633861376265633734653036223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A323A7B733A33323A223833313531346431633435383532616230333633383965306131346661353865223B733A33323A223364613034343836373731656161383333386532623039366135393438623161223B733A33323A223733363063663464373639343631663036356533633965343331656134323865223B733A33323A223836323936366639666137396139323265363362373739333265663664313533223B7D733A343A2268617368223B733A36353A2238363239363666396661373961393232653633623737393332656636643135332D3733363063663464373639343631663036356533633965343331656134323865223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D,1708097660),('0ea093ffe52e34a370883e5d836527c1',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730383335363536392E38323634323B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223065613039336666653532653334613337303838336535643833363532376331223B7D7D,1708356569),('0ede324ffb88f334bccf4cd189cb5820',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393638343337312E3433323634333B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223065646533323466666238386633333462636366346364313839636235383230223B7D7D,1709684371),('0f643aaaa0db1fe2f71059eed578d891',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393731333039342E3039333236333B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223066363433616161613064623166653266373130353965656435373864383931223B7D7D,1709713094),('14ea597ff310f9c4f52bf79272222443',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836363935392E3837343538323B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223134656135393766663331306639633466353262663739323732323232343433223B7D7D,1709866959),('18ee14b467d444c79402fd118819f274',0x5F5F4C616D696E61737C613A333A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730383039373035312E3331313636333B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223138656531346234363764343434633739343032666431313838313966323734223B7D733A34323A224C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730383130303635313B7D7D72656469726563745F75726C7C733A33343A22687474703A2F2F7464637732342E67656E657261746575722E6172742F61646D696E223B4C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A223732343735393363313161353661323866373964633334303465663063343231223B733A33323A223262356537393132626362626164633333346663613237623565353062653831223B7D733A343A2268617368223B733A36353A2232623565373931326263626261646333333466636132376235653530626538312D3732343735393363313161353661323866373964633334303465663063343231223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D,1708097051),('1935c2916bfed0ab748a795e1da90cc6',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730383338323434372E3037373139373B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223139333563323931366266656430616237343861373935653164613930636336223B7D7D,1708382447),('1a2af7e78908367a42cf8452a706ca02',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730383439393034362E3436343435323B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223161326166376537383930383336376134326366383435326137303663613032223B7D7D,1708499046),('276b5f0e95a80fb44adb67eac7f8deb5',0x5F5F4C616D696E61737C613A333A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393535353033382E31313335373B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223766396337613762316231306539333536313533373463373336666534306262223B7D733A34323A224C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393330353237313B7D7D72656469726563745F75726C7C733A33353A2268747470733A2F2F7464637732342E67656E657261746575722E6172742F61646D696E223B4C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A343A7B733A33323A223863313639646237646537383532343038656464343566333938356433313761223B733A33323A226334653162663864336362386439383037343461336535316363616632303433223B733A33323A226163353565656631333566386237626365343432613562656261373066393333223B733A33323A223064633965633034643266323137663931633265623936306163353631616236223B733A33323A223437353036616137306437343063346335653464393333663163663561346465223B733A33323A223235393634363366653739306161656635316633333763336633316237393634223B733A33323A226661643564663162383232346230623439346665363366626539663865656337223B733A33323A223433323663616537333931323831313938353037333764393337356633323339223B7D733A343A2268617368223B733A36353A2234333236636165373339313238313139383530373337643933373566333233392D6661643564663162383232346230623439346665363366626539663865656337223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4F6D656B614D657373656E6765727C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A303A7B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F417574687C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A313A7B733A373A2273746F72616765223B693A333B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D,1709555038),('2ae056a6462654cfe036172ece0ee458',0x5F5F4C616D696E61737C613A363A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393539333737382E3338383434363B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223666366138363863653062666432363330623563666533333638636665633639223B7D733A34323A224C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730383039373932393B7D733A34373A224C616D696E61735F56616C696461746F725F437372665F73616C745F766F636162756C617279666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730383039383431343B7D733A35333A224C616D696E61735F56616C696461746F725F437372665F73616C745F7265736F7572636574656D706C617465666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730383039383431373B7D733A33323A224C616D696E61735F56616C696461746F725F437372665F73616C745F63737266223B613A313A7B733A363A22455850495245223B693A313730393330363737363B7D7D72656469726563745F75726C7C733A33353A2268747470733A2F2F7464637732342E67656E657261746575722E6172742F61646D696E223B4C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A383A7B733A33323A223434326465653230636564306334333364313232363462626631343930393564223B733A33323A223235376665636237323337623031396265393562363438323063333963326533223B733A33323A226661303230336434636363373162386661303239626363373934643531623566223B733A33323A226239363530336566643361636636333166626436323438633533616534316535223B733A33323A226532363162653730623565303635363863613737343234313665376262343839223B733A33323A223631386164653964653831633136376662393663346534656661343237323937223B733A33323A223463353831623136306238623433663234376235613236346531306330313230223B733A33323A223866333131333863343535393436346465303937313064373831643833363563223B733A33323A223531616565323930303838633839373338373536333262653637623531343834223B733A33323A226262376466643832623364646461336539623364306163626539363763613162223B733A33323A223038363538393963653665646338376662336337336435363133646334343962223B733A33323A223638633830323432356439613731393565363834633764336662613732616439223B733A33323A226533626462636530656237343563396464306164343833643733333339633031223B733A33323A223264316238363965316161336635333633616533323933383063363363393539223B733A33323A223739353836393865316230316661616566663466326165306139636162616666223B733A33323A226362636632393938366265366536646133666633363837626465323535613632223B7D733A343A2268617368223B733A36353A2263626366323939383662653665366461336666333638376264653235356136322D3739353836393865316230316661616566663466326165306139636162616666223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4F6D656B614D657373656E6765727C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A303A7B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F417574687C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A313A7B733A373A2273746F72616765223B693A363B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F766F636162756C617279666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A323A7B733A33323A226638316234326435363562363338363537306465656437343461623133346239223B733A33323A223032393166656633613232363239386661393635366137653266386334326561223B733A33323A223536666562313362343536363730633937373562646439663934346232656333223B733A33323A226239636566343438663961393632363536383939643034313336313739613135223B7D733A343A2268617368223B733A36353A2262396365663434386639613936323635363839396430343133363137396131352D3536666562313362343536363730633937373562646439663934346232656333223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F7265736F7572636574656D706C617465666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A333A7B733A33323A226262666338346164636535363033653163646630303731323135306237363239223B733A33323A226536303766333563353031636635663166363637323831306666666535623363223B733A33323A223433636134363165353935316638636561376433363466616461303066666664223B733A33323A223036633432383530333466313030646134643962373932323739323835656366223B733A33323A223766313638323037653539343438653363373832373861356530303565303934223B733A33323A223731316462353666306266653731656230626130336337323937306533636237223B7D733A343A2268617368223B733A36353A2237313164623536663062666537316562306261303363373239373065336362372D3766313638323037653539343438653363373832373861356530303565303934223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A31353A7B733A33323A223961306538636335303338653632353064316263363233656333313234303332223B733A33323A226161663138626332623837393134616137343265663064373562613635326334223B733A33323A223961613365323935666331336662373737666330393737393965613361646264223B733A33323A226539333436303733616233663134366232323566353736326134613962306263223B733A33323A223132336663383137343432393338316233333132353933646334663432316163223B733A33323A226239663764333764616136633038646436666161663534343463333633376137223B733A33323A223033353066323730323939636265306166363235653966616336616562653638223B733A33323A223064353565353366343463386537643037376236333337613665616435383835223B733A33323A223161636633323033396561636264356138313839323564306632386665363637223B733A33323A226335363464393961616639323938303631613334376261333961376266353838223B733A33323A226138633563383634363139343634343237643764396336363662633237623761223B733A33323A223939626637646437636634646637613337613235383833396134356665616138223B733A33323A226261663266323732336530626331656665303137376464643561643936346135223B733A33323A223437643633316536666236313131353061333432663639343138333464626232223B733A33323A223035626636636336343231323266663963333265663639373964336634363233223B733A33323A223833306232373565363331323131636430643938386565363761633439376663223B733A33323A226263363666666164663361373339396364343766396237393165356164646263223B733A33323A223434383565656239663936366233366334386137663530373639343438356166223B733A33323A223237353466373262363364323764663131346464653536646366613866633566223B733A33323A226335323837353763666262326437663535306537373835633732613835636165223B733A33323A223731653334306131346564303138643464326331376364316431366464646363223B733A33323A223861636330336632353739336333663039343765633836633665623837386139223B733A33323A223830316365363965343662313931636563643862623533376633343139663338223B733A33323A226330663237616137376231333461373362313363353563373839656639323565223B733A33323A223737336231633232306136346430653864643039663932313864353363616263223B733A33323A223630363766303035613232313835656363626562353939343432336530656135223B733A33323A223434353737383836303564626566303834643237643965653734326266663633223B733A33323A223439376361383338333231383833383831313562336333646666646366633239223B733A33323A226137313563303237663830313336633265613431303963333531663035613230223B733A33323A223637396662326362306236386562306363383337336433623532646432313266223B7D733A343A2268617368223B733A36353A2236373966623263623062363865623063633833373364336235326464323132662D6137313563303237663830313336633265613431303963333531663035613230223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D,1709593778),('2e3f3a07c7bba101e92eac83d6f09c1f',0x5F5F4C616D696E61737C613A333A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393330343137312E3337323537333B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223865643332643965666365343030326539346166353533656339326531346136223B7D733A34323A224C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393237393236373B7D7D72656469726563745F75726C7C733A33353A2268747470733A2F2F7464637732342E67656E657261746575722E6172742F61646D696E223B4C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A223465323838306635613361373166656465393439376662386530363137313930223B733A33323A223737376431323238306363326235326666363030333839303664643939373762223B7D733A343A2268617368223B733A36353A2237373764313232383063633262353266663630303338393036646439393737622D3465323838306635613361373166656465393439376662386530363137313930223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F417574687C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A303A7B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4F6D656B614D657373656E6765727C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A313A7B733A383A226D65737361676573223B613A313A7B693A313B613A313A7B693A303B733A32333A225375636365737366756C6C79206C6F67676564206F7574223B7D7D7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D,1709304171),('2e978477b86e886079f127a726e599ec',0x5F5F4C616D696E61737C613A343A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393637313039302E3733353131333B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223337366336343062396332343939643466636237363434386164306236353262223B7D733A34323A224C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393330373739383B7D733A33323A224C616D696E61735F56616C696461746F725F437372665F73616C745F63737266223B613A313A7B733A363A22455850495245223B693A313730393637343639303B7D7D72656469726563745F75726C7C733A33353A2268747470733A2F2F7464637732342E67656E657261746575722E6172742F61646D696E223B4C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A226635383236636130623561613261343332323566613833373933663031623738223B733A33323A226434623536613861363863333137306436383866613430353131373464313564223B7D733A343A2268617368223B733A36353A2264346235366138613638633331373064363838666134303531313734643135642D6635383236636130623561613261343332323566613833373933663031623738223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F417574687C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A313A7B733A373A2273746F72616765223B693A353B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4F6D656B614D657373656E6765727C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A303A7B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A223265656133383130376237643534373632386233633163393030396433376461223B733A33323A226136636237646566323766373134303935326331646132613139306664323232223B7D733A343A2268617368223B733A36353A2261366362376465663237663731343039353263316461326131393066643232322D3265656133383130376237643534373632386233633163393030396433376461223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D,1709671090),('361dd1ddf6725fae1eaf4749a2b3e970',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730383338323131392E33393430323B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223336316464316464663637323566616531656166343734396132623365393730223B7D7D,1708382119),('39696d65052fff244f1add3a14eceb30',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836313332342E3032363037383B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223339363936643635303532666666323434663161646433613134656365623330223B7D7D,1709861324),('3b3e45b817b01c57488e212bac566040',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393331363237332E3030383633343B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223362336534356238313762303163353734383865323132626163353636303430223B7D7D72656469726563745F75726C7C733A33353A2268747470733A2F2F7464637732342E67656E657261746575722E6172742F61646D696E223B,1709316273),('3efce650bb6950e4e936946ca5a6bc98',0x5F5F4C616D696E61737C613A333A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836313233332E3934363434333B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223366383635633030353837313361383163643135663963316166623963303562223B7D733A34323A224C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393836343833333B7D7D72656469726563745F75726C7C733A34303A2268747470733A2F2F7464637732342E67656E657261746575722E6172742F61646D696E2F6974656D223B4C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A333A7B733A33323A226561323130346537323137623432313338303632396631333138326639393434223B733A33323A223335663835333036366366653863623731323831306562356162626561633366223B733A33323A226661643930363263353736326261343636316636356663643034383766306664223B733A33323A223066333731313761336662306563626665633037616438363939653136303461223B733A33323A223962303636376137623665653763636161326432323165613166333861633930223B733A33323A223836333963383931333033643034643230346338316162626162393636633736223B7D733A343A2268617368223B733A36353A2238363339633839313330336430346432303463383161626261623936366337362D3962303636376137623665653763636161326432323165613166333861633930223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4F6D656B614D657373656E6765727C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A303A7B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D,1709861233),('4373e1fe13666c15fb4ef36c0bfd4ea9',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836353532352E3332393435313B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223433373365316665313336363663313566623465663336633062666434656139223B7D7D,1709865525),('4516ae10cbc892662789b8aa2caa8b65',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836353533332E39313835313B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223435313661653130636263383932363632373839623861613263616138623635223B7D7D,1709865533),('47f9665c45501ce84c8de4faaf76c4ee',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836333731362E3439303136383B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223437663936363563343535303163653834633864653466616166373663346565223B7D7D,1709863716),('4fcd2bb17d89120c16f5ddbea8afe090',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730383338323434352E3933323132343B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223466636432626231376438393132306331366635646462656138616665303930223B7D7D,1708382445),('525a8ea07adb6662c612b438483ebcd5',0x5F5F4C616D696E61737C613A353A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393931343634392E3238383536313B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226131666334343961343731366466366131323637643933313765323062353162223B7D733A34323A224C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730383039383232373B7D733A34373A224C616D696E61735F56616C696461746F725F437372665F73616C745F766F636162756C617279666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730383634383839353B7D733A34343A224C616D696E61735F56616C696461746F725F437372665F73616C745F636F6E6669726D666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393931383234363B7D7D72656469726563745F75726C7C733A33353A2268747470733A2F2F7464637732342E67656E657261746575722E6172742F61646D696E223B4C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A373A7B733A33323A223834333031356532333336656538656135383763663334366633656237636562223B733A33323A226638656266653431386662303461386239643038343337363433653935656335223B733A33323A223234383637666263366561363337323132383865663639383664356238356438223B733A33323A226137626433383134306364383738653039626534353239393830353233376363223B733A33323A223462636262646633616662313865383032386630356363313866323139653663223B733A33323A226634623832333736613164633664643666393963663561643931653466373137223B733A33323A226638313738636134386431346434346437643234363231336666623235373664223B733A33323A223533333839356338396166343732623836653334653739653130663034343965223B733A33323A223836613565373934323964353939636331333437646364633464306330333164223B733A33323A223136346236313565646438313233316262616432656638663032373931646166223B733A33323A223132653563393231303566333931333064393130373537653963613432333861223B733A33323A223533383661376232313736376264633330323939323632396361636137666261223B733A33323A223661643833386330346230616663343030313334373538373361306232303330223B733A33323A226230616332326666323636373564383035306166646232353535373832663361223B7D733A343A2268617368223B733A36353A2262306163323266663236363735643830353061666462323535353738326633612D3661643833386330346230616663343030313334373538373361306232303330223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4F6D656B614D657373656E6765727C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A303A7B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F417574687C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A313A7B733A373A2273746F72616765223B693A31303B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F766F636162756C617279666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A223061623736333636353838326433366530626237366461356436366265353062223B733A33323A223939313831653965663931316364363930653834623235616132316264663033223B7D733A343A2268617368223B733A36353A2239393138316539656639313163643639306538346232356161323162646630332D3061623736333636353838326433366530626237366461356436366265353062223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F636F6E6669726D666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A323A7B733A33323A223662323938663063346631653234643530643664393733356461373864343261223B733A33323A226235383634356232313635646131336535616532363463646434666364636431223B733A33323A223563633333636633656562393936646661386139323835366238306666636362223B733A33323A223639333265643538626133633835366335343563396436623132326635646130223B7D733A343A2268617368223B733A36353A2236393332656435386261336338353663353435633964366231323266356461302D3563633333636633656562393936646661386139323835366238306666636362223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D,1709914649),('54d5a9571f314d3961e1196c1a8bd2b9',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393931343636312E3134363131333B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223534643561393537316633313464333936316531313936633161386264326239223B7D7D,1709914661),('5587b7e42ff96fb76f428433b94ba845',0x5F5F4C616D696E61737C613A363A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393331363639312E33383338343B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223161643065633332643235383832363636373666356231643535306332633366223B7D733A34323A224C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393330373736333B7D733A34373A224C616D696E61735F56616C696461746F725F437372665F73616C745F766F636162756C617279666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393330383134343B7D733A34343A224C616D696E61735F56616C696461746F725F437372665F73616C745F636F6E6669726D666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393331393832383B7D733A33323A224C616D696E61735F56616C696461746F725F437372665F73616C745F63737266223B613A313A7B733A363A22455850495245223B693A313730393330383237323B7D7D72656469726563745F75726C7C733A33353A2268747470733A2F2F7464637732342E67656E657261746575722E6172742F61646D696E223B4C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A223837383737303835326638376139616430373932323965623934666435616630223B733A33323A223962326365353332653238373530373334306334623531613437323330636266223B7D733A343A2268617368223B733A36353A2239623263653533326532383735303733343063346235316134373233306362662D3837383737303835326638376139616430373932323965623934666435616630223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F417574687C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A313A7B733A373A2273746F72616765223B693A323B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4F6D656B614D657373656E6765727C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A303A7B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F766F636162756C617279666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A223462363263613738383330343336613233343163326365323534316636646462223B733A33323A223739386565316536383431633266663366623832323761656461633233393833223B7D733A343A2268617368223B733A36353A2237393865653165363834316332666633666238323237616564616332333938332D3462363263613738383330343336613233343163326365323534316636646462223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F636F6E6669726D666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A323A7B733A33323A226661313637656331383930656163343166366531356239663632333461366633223B733A33323A223831663366393139316432656134393665373335383438623065633363346437223B733A33323A223331346561663361393933626233666534393439656432653238373961326634223B733A33323A226530363133343063366435663034336431623737666538663730626537666562223B7D733A343A2268617368223B733A36353A2265303631333430633664356630343364316237376665386637306265376665622D3331346561663361393933626233666534393439656432653238373961326634223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A226239363362633737343838633538616331306262373030356330363931383536223B733A33323A226637303830613562303536396437333866396335656638386231353231613264223B7D733A343A2268617368223B733A36353A2266373038306135623035363964373338663963356566383862313532316132642D6239363362633737343838633538616331306262373030356330363931383536223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D,1709316691),('563fc1b291e96b69d860f7dbf8c81e6c',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730383338323134312E3434343639343B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223536336663316232393165393662363964383630663764626638633831653663223B7D7D,1708382141),('568097bb496d07fcd01ca737ca33693f',0x5F5F4C616D696E61737C613A333A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393330343537342E3639363436373B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223536383039376262343936643037666364303163613733376361333336393366223B7D733A34323A224C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393330383137343B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A223539396161633733393039646262356230333466316531346336393131303034223B733A33323A226561336466646237333837646235333763663265646531633035663331613036223B7D733A343A2268617368223B733A36353A2265613364666462373338376462353337636632656465316330356633316130362D3539396161633733393039646262356230333466316531346336393131303034223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D,1709304574),('576f1e62809ebc04a20d69e52ab243dd',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393233323939392E3536343738313B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223537366631653632383039656263303461323064363965353261623234336464223B7D7D,1709232999),('5946e990596dc80397bea00b0825c069',0x5F5F4C616D696E61737C613A353A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393930373431362E3739333139353B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223031326562646431353939303738653735323438633365366135623765346566223B7D733A34323A224C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730383039383235323B7D733A33323A224C616D696E61735F56616C696461746F725F437372665F73616C745F63737266223B613A313A7B733A363A22455850495245223B693A313730393931313031363B7D733A34343A224C616D696E61735F56616C696461746F725F437372665F73616C745F636F6E6669726D666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393837323838373B7D7D72656469726563745F75726C7C733A33353A2268747470733A2F2F7464637732342E67656E657261746575722E6172742F61646D696E223B4C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A31323A7B733A33323A223961656162623462353466646133333263353362663835633737363363306631223B733A33323A223863373164386234383536326130383236356430353932303139333962626661223B733A33323A226434643532376635666533623735303264366637363066666231623331653862223B733A33323A223865663862303335366161323034356634666330666139356239376433343637223B733A33323A226362346334346339363463303062363162613066303364316533303835316532223B733A33323A226436623539376531613832343865666335633335303230373431376462356332223B733A33323A226232303435306564346330396635383330636430633239653162613564303631223B733A33323A223738306239663330623137643838613938373331643139363831656562366631223B733A33323A223966306236356535336363316430356638386336313734636362353031323061223B733A33323A226135343032326466666365363330303266316334376564663030386463316237223B733A33323A226439623161646237623237353234623565316662346532316461393065643033223B733A33323A223965666531666663623834636532613834386563386561313161363663396536223B733A33323A223466383165313366343835643933633066306430363237323664326262353162223B733A33323A223830373231353130616233343964383930623663656436663638656630643133223B733A33323A226362393766363066623036643230646164373232623531653531316662633564223B733A33323A223665616636623930386231356633306466646330396530323031366437623161223B733A33323A226430653231366235306564663336616534383031666432396664323233633866223B733A33323A226330336462653061336464386138396130666661643866356430626337636132223B733A33323A226439663332346463666262666465633231346261323165306430303731656135223B733A33323A226462343131643166303431633333633536326635306363656465633236316561223B733A33323A223937666161616263616135383439633462356564663639363536326664353535223B733A33323A223161643137373166393362376563323336366237383134633536393662313865223B733A33323A223133633733303736623637616132383864343832333663396535316564343262223B733A33323A226438663934646434393462623236313538313064633061376637376337393131223B7D733A343A2268617368223B733A36353A2264386639346464343934626232363135383130646330613766373763373931312D3133633733303736623637616132383864343832333663396535316564343262223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4F6D656B614D657373656E6765727C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A303A7B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F417574687C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A313A7B733A373A2273746F72616765223B693A373B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A223637613036623735636461326136623035323964666432303336646164353065223B733A33323A223762303764613231393566626530333835396132303232336131353431663463223B7D733A343A2268617368223B733A36353A2237623037646132313935666265303338353961323032323361313534316634632D3637613036623735636461326136623035323964666432303336646164353065223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F636F6E6669726D666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A33303A7B733A33323A223730303938353231316536383036653238383438306661356365653061616461223B733A33323A226635636239343262633032306231623736373461623139383337393966663463223B733A33323A226661663639356531333934386463346230313339646464643164636165656265223B733A33323A226135613839346462383937336432653939636433623031626166303034383739223B733A33323A226636393936366162633362643463616565643564376266323061363264383062223B733A33323A226165646431373936626563666361663937643730663732646237393130306466223B733A33323A226330343338303038643338313433653434393262623466313761653263306432223B733A33323A226536333038326130396433306565613765333731396162303936346233356365223B733A33323A223033373030653739623232323033393832303039653135396539333132353930223B733A33323A223264376636343266326436643236383662386334363138366262383839623932223B733A33323A226538643536386161343539636565396435363736326662363833313734316164223B733A33323A223762666634616365386139353735653132386633313434333866313362336233223B733A33323A223834336132353834613663336435396631316337303263393034653436623861223B733A33323A226564623362396331333838363937396166373264363231323738656530383038223B733A33323A223236626562383665626161386161616262643938656462323863376234663164223B733A33323A226365626466363832343438343437663331663536383435663330313233643130223B733A33323A223032353561653636666439616436613537303335373761653063393662613866223B733A33323A226137333338643431616339613563666139636336393662366561373464643132223B733A33323A223339613933333665656638333034343066333836643065386232363331613564223B733A33323A223431333031613361356362376235393434653538623063393532393961666534223B733A33323A223133353362376239313461343233643534396261353061626465626261666166223B733A33323A223638616530396563646565323230666331356335623164666634363962373734223B733A33323A223730353463313566613963623866666433323562616262643633323665626663223B733A33323A223365313064373332336637376439346432316465353438633935633633363534223B733A33323A223366343830356539393566373233633762393338383934363036613364333732223B733A33323A223639326234396435623262366163646639656234353330623965653864613364223B733A33323A226134333238666539636639636535396164353666626337383537373932666438223B733A33323A223436636239306434313734373134346265353135326165653730303863356666223B733A33323A226363393933376336643135653639363362323534323361663466613230323338223B733A33323A223163373162613533313064373233316566366335623764313165353232383534223B733A33323A223035353036626561653730353231643638316635316636366362386334626134223B733A33323A226637616337353033393264393035313162333162376462373436613930653734223B733A33323A223433336239613433303862353933626133643761656338376631363739313633223B733A33323A223663316462613030613862386235346136343964313635663137326662613061223B733A33323A226366653362393931386266363530643164643732326230333536643035663838223B733A33323A223638636466613735383664636534616135623032336337633435666430613161223B733A33323A223336316631656365326339613966316663333533353432626237383831333936223B733A33323A223637353031616532303830643239616133373037353463376436363362383534223B733A33323A226334636330653465306133373135343734643161383530636439313236663365223B733A33323A226432396139623237343439396330346538303734376330623536393537353962223B733A33323A223565383137383431373662306638326632633932306538613861623262366538223B733A33323A223862366338616264363364326265366563383866393864663563393133653761223B733A33323A226664663739313461656630636531363064356132646561303435333930633632223B733A33323A223664336439313332376365653363333661303463316431666439373934386537223B733A33323A226562303362333964643138643264303566353137363937636338653232363738223B733A33323A223364306464633066356665383631633937366363666431306364383231303964223B733A33323A223137623761636336646462363262326362363439616566636634333261616464223B733A33323A226262326435343463363561646233636138646234383239303038613539356330223B733A33323A223839623362643864323032393039326136383039343532313132636461333939223B733A33323A223861643162663863613030376162663865653539663332623761333433366534223B733A33323A223538383431363062623132323332313464333234636562653565356163386362223B733A33323A226664613537396638313837386439653761316334656339303533393333613164223B733A33323A223364656135303038613065336138643736303561353065323564333430306262223B733A33323A226366626563623966303337653335316532333633346639353636306234393862223B733A33323A223436333364616437616139396130373735386631343461336232336434643064223B733A33323A223432653564396161323566626261643936343731633032663739356635323933223B733A33323A226433353238643136396639343138313639643439316338636665313338306562223B733A33323A223931373539653463386662616438313565323261393339653033336264326335223B733A33323A226263313730663534326564643337313635346533326266343733646264396433223B733A33323A226530333738383138303064373166626464613630306639393233393130313733223B7D733A343A2268617368223B733A36353A2265303337383831383030643731666264646136303066393932333931303137332D6263313730663534326564643337313635346533326266343733646264396433223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D,1709907416),('5c11c549facec4611ffeb4f1f62401f3',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836313235372E373937363B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223563313163353439666163656334363131666665623466316636323430316633223B7D7D,1709861257),('5d64f38b7e2573cbd0a550578dc11699',0x5F5F4C616D696E61737C613A363A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393332313930312E37363136363B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226633323930643630326263386261663238646434613235346463366163613433223B7D733A34323A224C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393330373736373B7D733A33323A224C616D696E61735F56616C696461746F725F437372665F73616C745F63737266223B613A313A7B733A363A22455850495245223B693A313730393330383332343B7D733A34373A224C616D696E61735F56616C696461746F725F437372665F73616C745F766F636162756C617279666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393330383136333B7D733A34343A224C616D696E61735F56616C696461746F725F437372665F73616C745F636F6E6669726D666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393332353530313B7D7D72656469726563745F75726C7C733A33353A2268747470733A2F2F7464637732342E67656E657261746575722E6172742F61646D696E223B4C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A343A7B733A33323A223861366439373439306538623765663133643638633362613662386265646233223B733A33323A226231373533333833303130333638326537303166643839303639316236346662223B733A33323A226430363031393763343534346162663536396532643730303334333731356434223B733A33323A223630626536646465363766393239643236333462343134633138323430326264223B733A33323A223138353933643534663530316531326138346663306366616433626330356337223B733A33323A223762393537623561626538663861363733303136323638653130656334363539223B733A33323A223733613134313564306661386665663430613736643438346661643539363836223B733A33323A226133666537663938333066643062363461613661376464653938346535373764223B7D733A343A2268617368223B733A36353A2261336665376639383330666430623634616136613764646539383465353737642D3733613134313564306661386665663430613736643438346661643539363836223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4F6D656B614D657373656E6765727C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A303A7B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F417574687C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A313A7B733A373A2273746F72616765223B693A393B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A383A7B733A33323A226431336463646164393830373264373236653731613238633761323563346232223B733A33323A226534336337303232326331646462663564353964316461366461383764313639223B733A33323A223530616231643265643530353965326431386137643138313632633232656264223B733A33323A226134646161663836346137323764343533636463373264313437393364336231223B733A33323A223263356439623461333865333232316266323565336135313130383734383331223B733A33323A226632376562643232376664306237393566373736666630653039343664316639223B733A33323A226465303066353930393639363032383233663562346330373862316436643837223B733A33323A223265356131613930343961643463363136353731313934646239376636643030223B733A33323A223161653238636439376537646332353932313834373633313537666435653635223B733A33323A223533633039646330386532636138366435353338633062346166633130303831223B733A33323A223836663233393533663766643262316164613830643633326333343961626139223B733A33323A226438333537666632303030663537613730623236646237643136636363366265223B733A33323A223464653137623938343139663166303437313965623238623031636435323037223B733A33323A223562616462666333643336626436396665656133386433356535326139346431223B733A33323A226661376236306264303430653934653532623731643761386230363037346539223B733A33323A223932313038383032653161326365633135623030613336326536623330323361223B7D733A343A2268617368223B733A36353A2239323130383830326531613263656331356230306133363265366233303233612D6661376236306264303430653934653532623731643761386230363037346539223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F766F636162756C617279666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A323A7B733A33323A223764656461613237663633666333646661333963326163623936633930653461223B733A33323A223337323335323261623034613166356437386135303066313363383666373237223B733A33323A223565616165363462636232333664326665343230383739343364333766376362223B733A33323A223733386562643631343863366433323366363334666633323931616534343131223B7D733A343A2268617368223B733A36353A2237333865626436313438633664333233663633346666333239316165343431312D3565616165363462636232333664326665343230383739343364333766376362223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F636F6E6669726D666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A323A7B733A33323A223535313161643135323561333634646236363863313630356130323633663733223B733A33323A223830626433653530336361363165393735663861316430373933373836616464223B733A33323A223735336336633862323336343137636164626630306433316166353837393534223B733A33323A223732666663633566316635613662653837653765643434393130663435643631223B7D733A343A2268617368223B733A36353A2237326666636335663166356136626538376537656434343931306634356436312D3735336336633862323336343137636164626630306433316166353837393534223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D,1709321901),('631e9887d81d3bceaadfee02245695f9',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730383634353330332E3533313138393B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223633316539383837643831643362636561616466656530323234353639356639223B7D7D,1708645303),('6426a2b76597a9472c13aca7e0c5c3fe',0x5F5F4C616D696E61737C613A383A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393533353938302E3136363830333B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223666313337656230313739306631363637356537373163303037383236366238223B7D733A34323A224C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393330373737313B7D733A34373A224C616D696E61735F56616C696461746F725F437372665F73616C745F766F636162756C617279666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393330383032363B7D733A35393A224C616D696E61735F56616C696461746F725F437372665F73616C745F7265736F7572636574656D706C617465696D706F7274666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393330383233363B7D733A36353A224C616D696E61735F56616C696461746F725F437372665F73616C745F7265736F7572636574656D706C617465726576696577696D706F7274666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393330383236363B7D733A33323A224C616D696E61735F56616C696461746F725F437372665F73616C745F63737266223B613A313A7B733A363A22455850495245223B693A313730393330393138393B7D733A34343A224C616D696E61735F56616C696461746F725F437372665F73616C745F636F6E6669726D666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393533393538303B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A223563306363313464383939346262666536653433316265666632366665663761223B733A33323A226262626332323132616435623936303461313735353630336461393838666461223B7D733A343A2268617368223B733A36353A2262626263323231326164356239363034613137353536303364613938386664612D3563306363313464383939346262666536653433316265666632366665663761223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F417574687C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A313A7B733A373A2273746F72616765223B693A313B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4F6D656B614D657373656E6765727C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A303A7B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D72656469726563745F75726C7C4E3B4C616D696E61735F56616C696461746F725F437372665F73616C745F766F636162756C617279666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A223430663537633239316532363239353764316264653762313064653536663839223B733A33323A223739316137323233316165653163343736663130656230363734386434353637223B7D733A343A2268617368223B733A36353A2237393161373232333161656531633437366631306562303637343864343536372D3430663537633239316532363239353764316264653762313064653536663839223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F7265736F7572636574656D706C617465696D706F7274666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A223638363836383833353730666331366566363465393462356631666235343664223B733A33323A223865356630336263393730663831633363303066643632353562333731313666223B7D733A343A2268617368223B733A36353A2238653566303362633937306638316333633030666436323535623337313136662D3638363836383833353730666331366566363465393462356631666235343664223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F7265736F7572636574656D706C617465726576696577696D706F7274666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A223961333235323565656366393761383663313866303137613131626161363866223B733A33323A226163646164326634333137343634626662613637356635653130306433366263223B7D733A343A2268617368223B733A36353A2261636461643266343331373436346266626136373566356531303064333662632D3961333235323565656366393761383663313866303137613131626161363866223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A333A7B733A33323A223032666336306431623734363137303063346265626232326437346562623536223B733A33323A226236613533336331313364363261333962346238653636356562306239656162223B733A33323A223461613763373334376463303032316337353831656165343039313361646463223B733A33323A226139656264393364363866626134646461383039663665313865363762303266223B733A33323A226633663363623730303764313038666162336430326662386433376639343936223B733A33323A223036626266326631313962353331333136373035663538623630353865336631223B7D733A343A2268617368223B733A36353A2230366262663266313139623533313331363730356635386236303538653366312D6633663363623730303764313038666162336430326662386433376639343936223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F636F6E6669726D666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A323A7B733A33323A223035666230653237633532653133356464343139316537396433633530663566223B733A33323A223035356432373131306561393463653563343339356466333131346530643132223B733A33323A226637303934373534303332343839366237373464303561396564376439333164223B733A33323A226465626237333437326438333466653966323061653865303436326231336438223B7D733A343A2268617368223B733A36353A2264656262373334373264383334666539663230616538653034363262313364382D6637303934373534303332343839366237373464303561396564376439333164223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D,1709535980),('668f00583e3ea8bc7181fa730f00c148',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836313438392E3239333538383B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223636386630303538336533656138626337313831666137333066303063313438223B7D7D,1709861489),('68a31f9f4be4542a4bff3a9d94b0dc57',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836313233342E3736313232393B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223638613331663966346265343534326134626666336139643934623064633537223B7D7D,1709861234),('6a6fcc42e32fe9654fceeffd07618736',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836313232362E3431363037343B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223661366663633432653332666539363534666365656666643037363138373336223B7D7D,1709861226),('6cf6e1564ea21bad76680532c6cb9ce4',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393330353632382E3037313234313B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223663663665313536346561323162616437363638303533326336636239636534223B7D7D,1709305628),('6f839167bf4a2fadd8be2adf1f8fc412',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393330343537342E3436333139323B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223666383339313637626634613266616464386265326164663166386663343132223B7D7D72656469726563745F75726C7C733A33353A2268747470733A2F2F7464637732342E67656E657261746575722E6172742F61646D696E223B,1709304574),('6f92b75803d7a17a7fe78e1ca2cdfc32',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836313436372E3531383833363B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223666393262373538303364376131376137666537386531636132636466633332223B7D7D,1709861467),('75c6e4ec01e9914d40ea916e90f98daa',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730383634353239372E3437363730343B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223735633665346563303165393931346434306561393136653930663938646161223B7D7D,1708645297),('76c3b4a0e4c6306bdaad14fa24f67578',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836393238322E3535323331353B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223736633362346130653463363330366264616164313466613234663637353738223B7D7D,1709869282),('79240f7aa56a03632ee07c775ffb0072',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836363430312E3539363630373B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223739323430663761613536613033363332656530376337373566666230303732223B7D7D,1709866401),('79f234768d1c50f74ad1ffdb59e84617',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393330353632322E3138393039393B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223739663233343736386431633530663734616431666664623539653834363137223B7D7D,1709305622),('99bf7c6d6e23be2a148e084eac6819b9',0x5F5F4C616D696E61737C613A333A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393330343837372E3533383530333B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223939626637633664366532336265326131343865303834656163363831396239223B7D733A34323A224C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393330383437373B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A223036333861626139643034646662393565393338303831306336343331343637223B733A33323A226133613462336638336462623961373762313438373165356163343633353265223B7D733A343A2268617368223B733A36353A2261336134623366383364626239613737623134383731653561633436333532652D3036333861626139643034646662393565393338303831306336343331343637223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D,1709304877),('99d6aced861c9acef36c5bbd9289d25b',0x5F5F4C616D696E61737C613A333A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393331363237332E3233313330333B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223939643661636564383631633961636566333663356262643932383964323562223B7D733A34323A224C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393331393837333B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A223462396130313835333735646432363632343838663930323662396562626532223B733A33323A226230326663343139636561336565363033393063613738636631636365613736223B7D733A343A2268617368223B733A36353A2262303266633431396365613365653630333930636137386366316363656137362D3462396130313835333735646432363632343838663930323662396562626532223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D,1709316273),('9f4fa8fb87e4b75341083408b30a384c',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836393238382E37343532373B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223966346661386662383765346237353334313038333430386233306133383463223B7D7D,1709869288),('a1b2655a0d269734a49035b0d9068577',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836313235302E3333363133353B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226131623236353561306432363937333461343930333562306439303638353737223B7D7D,1709861250),('aa41876c5b1f4e22fc6e91f4e255b250',0x5F5F4C616D696E61737C613A343A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730383338323436332E3930363134343B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226166613938613137386339653231376139636163616262313638643430376661223B7D733A34323A224C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730383338353731373B7D733A33323A224C616D696E61735F56616C696461746F725F437372665F73616C745F63737266223B613A313A7B733A363A22455850495245223B693A313730383338363034353B7D7D72656469726563745F75726C7C733A34303A2268747470733A2F2F7464637732342E67656E657261746575722E6172742F61646D696E2F6974656D223B4C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A226333356133383437653231393134356164303234653639343233646333633930223B733A33323A223832633463353061346436653761616639346463393362366633646338383834223B7D733A343A2268617368223B733A36353A2238326334633530613464366537616166393464633933623666336463383838342D6333356133383437653231393134356164303234653639343233646333633930223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F417574687C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A313A7B733A373A2273746F72616765223B693A373B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4F6D656B614D657373656E6765727C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A303A7B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A223332346634653533633039343164313436336139656661663966343162353062223B733A33323A223935313837316538656663616139623536316636376464383162323639303363223B7D733A343A2268617368223B733A36353A2239353138373165386566636161396235363166363764643831623236393033632D3332346634653533633039343164313436336139656661663966343162353062223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D,1708382463),('b631ee360f1a507d677e1a200a68942d',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393233333030302E3532363636343B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226236333165653336306631613530376436373765316132303061363839343264223B7D7D,1709233000),('bad26c970a3725021c57433e4c110eac',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836313434382E3433353237373B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226261643236633937306133373235303231633537343333653463313130656163223B7D7D,1709861448),('bf9bc265b69f0b690dc9d53d85764550',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730383439393034362E3731353539383B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226266396263323635623639663062363930646339643533643835373634353530223B7D7D,1708499046),('c50851329b47e9b34cd95de33cac34de',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836333731382E3336353332393B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226335303835313332396234376539623334636439356465333363616333346465223B7D7D,1709863718),('c78ce266b3b3c9d6bd79e3d907ddd575',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730383932383136322E3435373935353B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226337386365323636623362336339643662643739653364393037646464353735223B7D7D,1708928162),('d9df8f8e4f91374f149e0ec991dda473',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393731333039352E3236303435333B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226439646638663865346639313337346631343965306563393931646461343733223B7D7D,1709713095),('dccfa7ee28bdc404dd92e7d4aee5f884',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393330343434332E3637353733363B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226463636661376565323862646334303464643932653764346165653566383834223B7D7D,1709304443),('de80d97ed951e06e2c6e23f860cfccae',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393336353138352E3635363037323B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226465383064393765643935316530366532633665323366383630636663636165223B7D7D,1709365185),('de9bbbd706458140a83f99efa061d4c4',0x5F5F4C616D696E61737C613A333A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393330353738342E3335313034353B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226465396262626437303634353831343061383366393965666130363164346334223B7D733A34323A224C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730393330393338343B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A223539303563313037333235326163656262616664353633396565363637383666223B733A33323A223362376266333638326463366562326334383762386666646362663464386163223B7D733A343A2268617368223B733A36353A2233623762663336383264633665623263343837623866666463626634643861632D3539303563313037333235326163656262616664353633396565363637383666223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D,1709305784),('e03fbb37e403fe140557bb3044ba9884',0x5F5F4C616D696E61737C613A353A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730383039363638302E3938313536393B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A223838643334313935323565306264363133306433323863653835656531633132223B7D733A34323A224C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730383039373732383B7D733A35313A224C616D696E61735F56616C696461746F725F437372665F73616C745F666F72676F7470617373776F7264666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730383039373732313B7D733A33323A224C616D696E61735F56616C696461746F725F437372665F73616C745F63737266223B613A313A7B733A363A22455850495245223B693A313730383039383332353B7D7D72656469726563745F75726C7C733A33353A2268747470733A2F2F7464637732342E67656E657261746575722E6172742F61646D696E223B4C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A333A7B733A33323A226332633965306433346332633733303231636261626532316535663534333036223B733A33323A223063663965303665343534663361616333633335356437376435353433656538223B733A33323A223037326164623530613635306434326465636664313835343933613730373361223B733A33323A226632336538393363636333386430613934383164643237323632393064643430223B733A33323A226165663766626462366433656536303366643434396463333963613364373964223B733A33323A223132616634373535326132656464383236356464333963333265383430323463223B7D733A343A2268617368223B733A36353A2231326166343735353261326564643832363564643339633332653834303234632D6165663766626462366433656536303366643434396463333963613364373964223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4F6D656B614D657373656E6765727C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A303A7B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F666F72676F7470617373776F7264666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A223836373638353538626665376164613866383730316362333837613237353235223B733A33323A223831346565346466326637326564316536343064656234306663393831303363223B7D733A343A2268617368223B733A36353A2238313465653464663266373265643165363430646562343066633938313033632D3836373638353538626665376164613866383730316362333837613237353235223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F417574687C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A313A7B733A373A2273746F72616765223B693A343B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A343A7B733A33323A226232303338633630326136653132623662306432336539313136336363396537223B733A33323A226636623832616461613764373261323839663731333030666138626262353761223B733A33323A226463343136656638346261373164323464613734643734626439616366623665223B733A33323A226536663439353634356161393431353437383733396131346237303066303536223B733A33323A223130633264643031633562633366616563386465343439393532643735343735223B733A33323A226330393530386465396365373138333834353232396137373734323561383032223B733A33323A223232363136366263656165316235633866373234366530636236356464623438223B733A33323A223864653466303963656635306662356138336535306466303638663366653166223B7D733A343A2268617368223B733A36353A2238646534663039636566353066623561383365353064663036386633666531662D3232363136366263656165316235633866373234366530636236356464623438223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D,1708096681),('e322b4b40716402f65ce0db7a5ba9aec',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393330353738342E3132373231393B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226533323262346234303731363430326636356365306462376135626139616563223B7D7D72656469726563745F75726C7C733A35333A2268747470733A2F2F7464637732342E67656E657261746575722E6172742F61646D696E2F7265736F757263652D74656D706C617465223B,1709305784),('e3a7d893198cafedc07fd0367acffb83',0x5F5F4C616D696E61737C613A333A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730383130353131312E3737383132363B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226533613764383933313938636166656463303766643033363761636666623833223B7D733A34323A224C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F63737266223B613A313A7B733A363A22455850495245223B693A313730383130383731313B7D7D4C616D696E61735F56616C696461746F725F437372665F73616C745F6C6F67696E666F726D5F637372667C4F3A32363A224C616D696E61735C5374646C69625C41727261794F626A656374223A343A7B733A373A2273746F72616765223B613A323A7B733A393A22746F6B656E4C697374223B613A313A7B733A33323A226535376330643339646334333036343939396432316165656663323738386361223B733A33323A226565306336373466346137353165613034356634306664386661383763633635223B7D733A343A2268617368223B733A36353A2265653063363734663461373531656130343566343066643866613837636336352D6535376330643339646334333036343939396432316165656663323738386361223B7D733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B733A31333A2241727261794974657261746F72223B733A31393A2270726F74656374656450726F70657274696573223B613A343A7B693A303B733A373A2273746F72616765223B693A313B733A343A22666C6167223B693A323B733A31333A226974657261746F72436C617373223B693A333B733A31393A2270726F74656374656450726F70657274696573223B7D7D,1708105111),('e5a96d04a6ded76c85dfe5de334d1e0f',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836363430362E3032313031383B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226535613936643034613664656437366338356466653564653333346431653066223B7D7D,1709866406),('e5d1b912e42d3d3099d33edef10ea8b6',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836363936342E3738303439343B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226535643162393132653432643364333039396433336564656631306561386236223B7D7D,1709866964),('e6cec3c859e65e0b0dad9e1d9d030adf',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836343731322E3832373233343B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226536636563336338353965363565306230646164396531643964303330616466223B7D7D,1709864712),('ef535ba7bda3daa3a7ccd98f9db268aa',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730383335363536382E333532313B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226566353335626137626461336461613361376363643938663964623236386161223B7D7D,1708356568),('f0a20bb52c5b2120d5e92f48cb79af2a',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836313332302E3731353738383B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226630613230626235326335623231323064356539326634386362373961663261223B7D7D,1709861320),('f2dbbf53f63b4ce8fd9a3413cd1a2eb3',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393836313231322E3938353731333B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226632646262663533663633623463653866643961333431336364316132656233223B7D7D,1709861213),('ffb150026e94cba8686ec4c5d59a13c2',0x5F5F4C616D696E61737C613A323A7B733A32303A225F524551554553545F4143434553535F54494D45223B643A313730393330343837372E3332343034363B733A363A225F56414C4944223B613A313A7B733A32383A224C616D696E61735C53657373696F6E5C56616C696461746F725C4964223B733A33323A226666623135303032366539346362613836383665633463356435396131336332223B7D7D72656469726563745F75726C7C733A34363A2268747470733A2F2F7464637732342E67656E657261746575722E6172742F61646D696E2F766F636162756C617279223B,1709304877);
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `setting`
--

DROP TABLE IF EXISTS `setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setting` (
  `id` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:json_array)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setting`
--

LOCK TABLES `setting` WRITE;
/*!40000 ALTER TABLE `setting` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `setting` VALUES ('administrator_email','\"samuel.szoniecky@univ-paris8.fr\"'),('annotate_public_allow_annotate','false'),('annotate_public_allow_view','true'),('annotate_resource_template_data','{\"2\":{\"oa:motivatedBy\":\"oa:Annotation\",\"rdf:value\":\"oa:hasBody\",\"oa:hasPurpose\":\"oa:hasBody\",\"dcterms:language\":\"oa:hasBody\",\"oa:hasSource\":\"oa:hasTarget\",\"rdf:type\":\"oa:hasTarget\",\"dcterms:format\":\"oa:hasTarget\"},\"3\":[]}'),('blockplus_html_config_page','\"default\"'),('blockplus_html_mode_page','\"inline\"'),('blockplus_property_itemset','\"\"'),('bulkexport_format_fields','\"name\"'),('bulkexport_format_generic','\"string\"'),('bulkexport_format_resource','\"id\"'),('bulkexport_format_resource_property','\"dcterms:identifier\"'),('bulkexport_format_uri','\"uri_label\"'),('bulkexport_formatters','[\"csv\",\"json-ld\",\"json-table\",\"ods\",\"tsv\",\"txt\"]'),('bulkexport_limit','1000'),('bulkexport_metadata','[\"o:id\",\"o:resource_template\",\"o:resource_class\",\"o:owner\",\"o:is_public\",\"properties_max_5000\"]'),('bulkexport_metadata_exclude','[\"bibo:content\",\"properties_min_5000\",\"extracttext:extracted_text\"]'),('bulkexport_template','\"\"'),('extension_whitelist','[\"aac\",\"aif\",\"aiff\",\"asf\",\"asx\",\"avi\",\"bmp\",\"c\",\"cc\",\"class\",\"css\",\"divx\",\"doc\",\"docx\",\"exe\",\"gif\",\"gz\",\"gzip\",\"h\",\"ico\",\"j2k\",\"jp2\",\"jpe\",\"jpeg\",\"jpg\",\"m4a\",\"m4v\",\"mdb\",\"mid\",\"midi\",\"mov\",\"mp2\",\"mp3\",\"mp4\",\"mpa\",\"mpe\",\"mpeg\",\"mpg\",\"mpp\",\"odb\",\"odc\",\"odf\",\"odg\",\"odp\",\"ods\",\"odt\",\"ogg\",\"opus\",\"pdf\",\"png\",\"pot\",\"pps\",\"ppt\",\"pptx\",\"qt\",\"ra\",\"ram\",\"rtf\",\"rtx\",\"swf\",\"tar\",\"tif\",\"tiff\",\"txt\",\"wav\",\"wax\",\"webm\",\"wma\",\"wmv\",\"wmx\",\"wri\",\"xla\",\"xls\",\"xlsx\",\"xlt\",\"xlw\",\"zip\"]'),('installation_title','\"Transnational Digital Creation Workshop 2024\"'),('locale','\"\"'),('media_type_whitelist','[\"application\\/msword\",\"application\\/ogg\",\"application\\/pdf\",\"application\\/rtf\",\"application\\/vnd.ms-access\",\"application\\/vnd.ms-excel\",\"application\\/vnd.ms-powerpoint\",\"application\\/vnd.ms-project\",\"application\\/vnd.ms-write\",\"application\\/vnd.oasis.opendocument.chart\",\"application\\/vnd.oasis.opendocument.database\",\"application\\/vnd.oasis.opendocument.formula\",\"application\\/vnd.oasis.opendocument.graphics\",\"application\\/vnd.oasis.opendocument.presentation\",\"application\\/vnd.oasis.opendocument.spreadsheet\",\"application\\/vnd.oasis.opendocument.text\",\"application\\/vnd.openxmlformats-officedocument.wordprocessingml.document\",\"application\\/vnd.openxmlformats-officedocument.presentationml.presentation\",\"application\\/vnd.openxmlformats-officedocument.spreadsheetml.sheet\",\"application\\/x-gzip\",\"application\\/x-ms-wmp\",\"application\\/x-msdownload\",\"application\\/x-shockwave-flash\",\"application\\/x-tar\",\"application\\/zip\",\"audio\\/midi\",\"audio\\/mp4\",\"audio\\/mpeg\",\"audio\\/ogg\",\"audio\\/x-aac\",\"audio\\/x-aiff\",\"audio\\/x-ms-wma\",\"audio\\/x-ms-wax\",\"audio\\/x-realaudio\",\"audio\\/x-wav\",\"image\\/bmp\",\"image\\/gif\",\"image\\/jp2\",\"image\\/jpeg\",\"image\\/pjpeg\",\"image\\/png\",\"image\\/tiff\",\"image\\/x-icon\",\"text\\/css\",\"text\\/plain\",\"text\\/richtext\",\"video\\/divx\",\"video\\/mp4\",\"video\\/mpeg\",\"video\\/ogg\",\"video\\/quicktime\",\"video\\/webm\",\"video\\/x-ms-asf,\",\"video\\/x-msvideo\",\"video\\/x-ms-wmv\"]'),('pagination_per_page','25'),('time_zone','\"Europe\\/Paris\"'),('use_htmlpurifier','\"1\"'),('version','\"4.0.4\"'),('version_notifications','\"1\"');
/*!40000 ALTER TABLE `setting` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `site`
--

DROP TABLE IF EXISTS `site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `thumbnail_id` int(11) DEFAULT NULL,
  `homepage_id` int(11) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `slug` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `theme` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `navigation` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:json_array)',
  `item_pool` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:json_array)',
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL,
  `assign_new_items` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_694309E4989D9B62` (`slug`),
  UNIQUE KEY `UNIQ_694309E4571EDDA` (`homepage_id`),
  KEY `IDX_694309E4FDFF2E92` (`thumbnail_id`),
  KEY `IDX_694309E47E3C61F9` (`owner_id`),
  CONSTRAINT `FK_694309E4571EDDA` FOREIGN KEY (`homepage_id`) REFERENCES `site_page` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_694309E47E3C61F9` FOREIGN KEY (`owner_id`) REFERENCES `user` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_694309E4FDFF2E92` FOREIGN KEY (`thumbnail_id`) REFERENCES `asset` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site`
--

LOCK TABLES `site` WRITE;
/*!40000 ALTER TABLE `site` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `site` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `site_block_attachment`
--

DROP TABLE IF EXISTS `site_block_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_block_attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `block_id` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `media_id` int(11) DEFAULT NULL,
  `caption` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_236473FEE9ED820C` (`block_id`),
  KEY `IDX_236473FE126F525E` (`item_id`),
  KEY `IDX_236473FEEA9FDD75` (`media_id`),
  KEY `block_position` (`block_id`,`position`),
  CONSTRAINT `FK_236473FE126F525E` FOREIGN KEY (`item_id`) REFERENCES `item` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_236473FEE9ED820C` FOREIGN KEY (`block_id`) REFERENCES `site_page_block` (`id`),
  CONSTRAINT `FK_236473FEEA9FDD75` FOREIGN KEY (`media_id`) REFERENCES `media` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_block_attachment`
--

LOCK TABLES `site_block_attachment` WRITE;
/*!40000 ALTER TABLE `site_block_attachment` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `site_block_attachment` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `site_item_set`
--

DROP TABLE IF EXISTS `site_item_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_item_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `item_set_id` int(11) NOT NULL,
  `position` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_D4CE134F6BD1646960278D7` (`site_id`,`item_set_id`),
  KEY `IDX_D4CE134F6BD1646` (`site_id`),
  KEY `IDX_D4CE134960278D7` (`item_set_id`),
  KEY `position` (`position`),
  CONSTRAINT `FK_D4CE134960278D7` FOREIGN KEY (`item_set_id`) REFERENCES `item_set` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_D4CE134F6BD1646` FOREIGN KEY (`site_id`) REFERENCES `site` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_item_set`
--

LOCK TABLES `site_item_set` WRITE;
/*!40000 ALTER TABLE `site_item_set` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `site_item_set` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `site_page`
--

DROP TABLE IF EXISTS `site_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `slug` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_public` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_2F900BD9F6BD1646989D9B62` (`site_id`,`slug`),
  KEY `IDX_2F900BD9F6BD1646` (`site_id`),
  CONSTRAINT `FK_2F900BD9F6BD1646` FOREIGN KEY (`site_id`) REFERENCES `site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_page`
--

LOCK TABLES `site_page` WRITE;
/*!40000 ALTER TABLE `site_page` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `site_page` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `site_page_block`
--

DROP TABLE IF EXISTS `site_page_block`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_page_block` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `layout` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:json_array)',
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C593E731C4663E4` (`page_id`),
  KEY `page_position` (`page_id`,`position`),
  CONSTRAINT `FK_C593E731C4663E4` FOREIGN KEY (`page_id`) REFERENCES `site_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_page_block`
--

LOCK TABLES `site_page_block` WRITE;
/*!40000 ALTER TABLE `site_page_block` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `site_page_block` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `site_permission`
--

DROP TABLE IF EXISTS `site_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_C0401D6FF6BD1646A76ED395` (`site_id`,`user_id`),
  KEY `IDX_C0401D6FF6BD1646` (`site_id`),
  KEY `IDX_C0401D6FA76ED395` (`user_id`),
  CONSTRAINT `FK_C0401D6FA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_C0401D6FF6BD1646` FOREIGN KEY (`site_id`) REFERENCES `site` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_permission`
--

LOCK TABLES `site_permission` WRITE;
/*!40000 ALTER TABLE `site_permission` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `site_permission` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `site_setting`
--

DROP TABLE IF EXISTS `site_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_setting` (
  `id` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_id` int(11) NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:json_array)',
  PRIMARY KEY (`id`,`site_id`),
  KEY `IDX_64D05A53F6BD1646` (`site_id`),
  CONSTRAINT `FK_64D05A53F6BD1646` FOREIGN KEY (`site_id`) REFERENCES `site` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_setting`
--

LOCK TABLES `site_setting` WRITE;
/*!40000 ALTER TABLE `site_setting` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `site_setting` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `password_hash` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `user` VALUES (1,'samuel.szoniecky@univ-paris8.fr','Samuel Szoniecky','2024-01-28 08:19:37','2024-01-28 08:19:38','$2y$10$tfTQAHqPICn4XQtjPaGfcu8yLc3Za8ztfIfMf52qjGWBvsNmkqo76','global_admin',1),(2,'lxsgla@rit.edu','Laura Shackelford','2024-02-16 14:35:35','2024-02-16 14:36:05','$2y$10$JAJzyw2I.W.cHkOm3X2r7uEfhMQdS8hCX.90MhOenxhVqk.ZYqqGm','global_admin',1),(3,'ferroubel.mez@gmail.com','Ferroudja	Belkessa','2024-02-16 14:37:06','2024-02-16 14:42:33','$2y$10$cfg/0tzZuyuEO.F8CjV78.fQiPseUDdYRlf8HpKagDbewo4sv9mLm','global_admin',1),(4,'paulina.gniady@etud.univ-paris8.fr','Paulina	Gniady','2024-02-16 14:37:54','2024-02-16 14:45:24','$2y$10$sGbmIC3E6AVopLST9rcBru00ztkak43/oowR4kxEQk4VCUDl0p0j6','global_admin',1),(5,'edc3287@rit.edu','Erica Coles','2024-02-16 14:38:39','2024-02-16 14:44:47','$2y$10$ty.wX52EPhCHsEobyNKf0.r4lrLXYREhM8wz.5iVM.1MXUx6grhgi','global_admin',1),(6,'yannis.benzaid@etud.univ-paris8.fr','Yannis Benzaid','2024-02-16 14:38:55','2024-02-16 14:39:10','$2y$10$TCR/mCojzOfKaSLpK6UnlOM7Jdx7vWhIw325.hQKy837DNp2//WsS','global_admin',1),(7,'mfg3078@rit.edu','Matthew Giacovelli','2024-02-16 14:39:26','2024-02-16 14:44:03','$2y$10$JAkgWh6RuY7IGs.jlD5t6ux1HUq5CX.oI15aHqfANmzPtriTX7/2K','global_admin',1),(8,'chloeviala.contact@gmail.com','Chloe Viala','2024-02-16 14:39:45','2024-02-16 14:39:57','$2y$10$c9LQOLXlrYeUExFmaPVTgewQ5BarTAIGv0FeuAp4L6EmkEMisuvnW','global_admin',1),(9,'dbg9180@rit.edu','Deen Grey','2024-02-16 14:39:51','2024-02-16 14:45:03','$2y$10$O.rk6666FSkga99b5MVNNe5ml.XMEkN0LPl7rAOblzd3aOUrcRGq6','global_admin',1),(10,'hs7790@rit.edu','Harsh Shah','2024-02-16 14:40:18','2024-02-16 14:42:30','$2y$10$wj5YcYVpm0uamP4v8JUR4ua3ypSmseEr42oL/O6M.PUuvpvnX/wWa','global_admin',1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `user_setting`
--

DROP TABLE IF EXISTS `user_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_setting` (
  `id` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:json_array)',
  PRIMARY KEY (`id`,`user_id`),
  KEY `IDX_C779A692A76ED395` (`user_id`),
  CONSTRAINT `FK_C779A692A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_setting`
--

LOCK TABLES `user_setting` WRITE;
/*!40000 ALTER TABLE `user_setting` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `user_setting` VALUES ('browse_defaults_admin_item_sets',2,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_item_sets',3,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_item_sets',4,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_item_sets',5,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_item_sets',6,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_item_sets',7,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_item_sets',8,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_item_sets',9,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_item_sets',10,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_items',2,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_items',3,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_items',4,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_items',5,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_items',6,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_items',7,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_items',8,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_items',9,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_items',10,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_media',2,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_media',3,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_media',4,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_media',5,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_media',6,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_media',7,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_media',8,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_media',9,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_media',10,'{\"sort_by\":\"created\",\"sort_order\":\"desc\"}'),('browse_defaults_admin_sites',2,'{\"sort_by\":\"title\",\"sort_order\":\"asc\"}'),('browse_defaults_admin_sites',3,'{\"sort_by\":\"title\",\"sort_order\":\"asc\"}'),('browse_defaults_admin_sites',4,'{\"sort_by\":\"title\",\"sort_order\":\"asc\"}'),('browse_defaults_admin_sites',5,'{\"sort_by\":\"title\",\"sort_order\":\"asc\"}'),('browse_defaults_admin_sites',6,'{\"sort_by\":\"title\",\"sort_order\":\"asc\"}'),('browse_defaults_admin_sites',7,'{\"sort_by\":\"title\",\"sort_order\":\"asc\"}'),('browse_defaults_admin_sites',8,'{\"sort_by\":\"title\",\"sort_order\":\"asc\"}'),('browse_defaults_admin_sites',9,'{\"sort_by\":\"title\",\"sort_order\":\"asc\"}'),('browse_defaults_admin_sites',10,'{\"sort_by\":\"title\",\"sort_order\":\"asc\"}'),('columns_admin_item_sets',2,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_item_sets',3,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_item_sets',4,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_item_sets',5,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_item_sets',6,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_item_sets',7,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_item_sets',8,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_item_sets',9,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_item_sets',10,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_items',2,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_items',3,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_items',4,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_items',5,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_items',6,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_items',7,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_items',8,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_items',9,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_items',10,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_media',2,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_media',3,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_media',4,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_media',5,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_media',6,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_media',7,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_media',8,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_media',9,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_media',10,'[{\"type\":\"resource_class\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_sites',2,'[{\"type\":\"slug\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_sites',3,'[{\"type\":\"slug\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_sites',4,'[{\"type\":\"slug\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_sites',5,'[{\"type\":\"slug\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_sites',6,'[{\"type\":\"slug\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_sites',7,'[{\"type\":\"slug\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_sites',8,'[{\"type\":\"slug\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_sites',9,'[{\"type\":\"slug\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('columns_admin_sites',10,'[{\"type\":\"slug\",\"default\":null,\"header\":null},{\"type\":\"owner\",\"default\":null,\"header\":null},{\"type\":\"created\",\"default\":null,\"header\":null}]'),('default_resource_template',2,'\"\"'),('default_resource_template',3,'\"\"'),('default_resource_template',4,'\"\"'),('default_resource_template',5,'\"\"'),('default_resource_template',6,'\"\"'),('default_resource_template',7,'\"\"'),('default_resource_template',8,'\"\"'),('default_resource_template',9,'\"\"'),('default_resource_template',10,'\"\"'),('locale',2,'\"\"'),('locale',3,'\"\"'),('locale',4,'\"\"'),('locale',5,'\"\"'),('locale',6,'\"\"'),('locale',7,'\"\"'),('locale',8,'\"\"'),('locale',9,'\"\"'),('locale',10,'\"\"');
/*!40000 ALTER TABLE `user_setting` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `value`
--

DROP TABLE IF EXISTS `value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `value` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `value_resource_id` int(11) DEFAULT NULL,
  `value_annotation_id` int(11) DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uri` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_1D7758349B66727E` (`value_annotation_id`),
  KEY `IDX_1D77583489329D25` (`resource_id`),
  KEY `IDX_1D775834549213EC` (`property_id`),
  KEY `IDX_1D7758344BC72506` (`value_resource_id`),
  KEY `value` (`value`(190)),
  KEY `uri` (`uri`(190)),
  CONSTRAINT `FK_1D7758344BC72506` FOREIGN KEY (`value_resource_id`) REFERENCES `resource` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_1D775834549213EC` FOREIGN KEY (`property_id`) REFERENCES `property` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_1D77583489329D25` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `FK_1D7758349B66727E` FOREIGN KEY (`value_annotation_id`) REFERENCES `value_annotation` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `value`
--

LOCK TABLES `value` WRITE;
/*!40000 ALTER TABLE `value` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `value` VALUES (1,1,1,NULL,NULL,'literal','','Tom & Jerry pursuit',NULL,1),(2,1,4,NULL,NULL,'literal','','Tom try to catch Jerry and eat him',NULL,1),(3,1,243,NULL,NULL,'literal','','Tom',NULL,1),(4,1,243,NULL,NULL,'literal','','Jerry',NULL,1),(5,1,243,NULL,NULL,'literal','','A women',NULL,1),(6,1,244,NULL,NULL,'literal','','piece of cheese',NULL,1),(7,1,244,NULL,NULL,'literal','','hammer',NULL,1),(8,1,244,NULL,NULL,'literal','','mouse hole',NULL,1),(9,1,244,NULL,NULL,'literal','','cat basket',NULL,1),(10,1,247,NULL,NULL,'literal','','kitchen',NULL,1),(11,1,247,NULL,NULL,'literal','','garden',NULL,1),(12,1,247,NULL,NULL,'literal','','stare',NULL,1),(13,1,246,NULL,NULL,'literal','','fear',NULL,1),(14,1,246,NULL,NULL,'literal','','scream',NULL,1),(15,1,246,NULL,NULL,'literal','','hunger',NULL,1),(16,1,246,NULL,NULL,'literal','','tears',NULL,1),(17,1,245,NULL,NULL,'literal','','Tom see Jerry',NULL,1),(18,1,245,NULL,NULL,'literal','','Jerry run away',NULL,1),(19,1,245,NULL,NULL,'literal','','Jerry go to his mouse hole',NULL,1),(20,2,1,NULL,NULL,'literal','','A future with artificial intelligence',NULL,1),(21,2,4,NULL,NULL,'literal','','The United States with Russia, China, and the European Union are making policy decisions to see what the role of AI in the world will be.',NULL,1),(22,2,243,NULL,NULL,'literal','','Concerned activist\nIgnorant US Senator\nEvil Russian world leader\nFrench politician\nChinese politician',NULL,1),(23,2,244,NULL,NULL,'literal','','Gavel',NULL,1),(24,2,247,NULL,NULL,'literal','','United Nations in New York City',NULL,1),(25,2,246,NULL,NULL,'literal','','Angry\nSadness\nHappiness',NULL,1),(26,2,245,NULL,NULL,'literal','','Gavel is banged\nGreat legislation is passed\nPoor legislation is passed',NULL,1);
/*!40000 ALTER TABLE `value` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `value_annotation`
--

DROP TABLE IF EXISTS `value_annotation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `value_annotation` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_C03BA4EBF396750` FOREIGN KEY (`id`) REFERENCES `resource` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `value_annotation`
--

LOCK TABLES `value_annotation` WRITE;
/*!40000 ALTER TABLE `value_annotation` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `value_annotation` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `vocabulary`
--

DROP TABLE IF EXISTS `vocabulary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vocabulary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) DEFAULT NULL,
  `namespace_uri` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prefix` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_9099C97B9B267FDF` (`namespace_uri`),
  UNIQUE KEY `UNIQ_9099C97B93B1868E` (`prefix`),
  KEY `IDX_9099C97B7E3C61F9` (`owner_id`),
  CONSTRAINT `FK_9099C97B7E3C61F9` FOREIGN KEY (`owner_id`) REFERENCES `user` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vocabulary`
--

LOCK TABLES `vocabulary` WRITE;
/*!40000 ALTER TABLE `vocabulary` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `vocabulary` VALUES (1,NULL,'http://purl.org/dc/terms/','dcterms','Dublin Core','Basic resource metadata (DCMI Metadata Terms)'),(2,NULL,'http://purl.org/dc/dcmitype/','dctype','Dublin Core Type','Basic resource types (DCMI Type Vocabulary)'),(3,NULL,'http://purl.org/ontology/bibo/','bibo','Bibliographic Ontology','Bibliographic metadata (BIBO)'),(4,NULL,'http://xmlns.com/foaf/0.1/','foaf','Friend of a Friend','Relationships between people and organizations (FOAF)'),(5,1,'http://www.w3.org/ns/oa#','oa','Web Annotation Ontology','The Web Annotation Vocabulary specifies the set of RDF classes, predicates and named entities that are used by the Web Annotation Data Model (http://www.w3.org/TR/annotation-model/).'),(6,1,'http://www.w3.org/1999/02/22-rdf-syntax-ns#','rdf','The RDF Concepts Vocabulary (RDF)','This is the RDF Schema for the RDF vocabulary terms in the RDF Namespace, defined in RDF 1.1 Concepts.'),(7,1,'https://omeka.org/s/vocabs/curation/','curation','Curation','Generic and common properties that are useful in Omeka for the curation of resources. The use of more common or more precise ontologies is recommended when it is possible.'),(8,1,'https://jardindesconnaissances.univ-paris8.fr/onto/genstory#','genstory','GenStory','');
/*!40000 ALTER TABLE `vocabulary` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `annotation_part`
--

DROP TABLE IF EXISTS `annotation_part`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `annotation_part` (
  `id` int(11) NOT NULL,
  `annotation_id` int(11) DEFAULT NULL,
  `part` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_4ABEA042E075FC54` (`annotation_id`),
  KEY `idx_part` (`part`),
  CONSTRAINT `FK_4ABEA042BF396750` FOREIGN KEY (`id`) REFERENCES `resource` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_4ABEA042E075FC54` FOREIGN KEY (`annotation_id`) REFERENCES `annotation` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `annotation_part`
--

LOCK TABLES `annotation_part` WRITE;
/*!40000 ALTER TABLE `annotation_part` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `annotation_part` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `bulk_export`
--

DROP TABLE IF EXISTS `bulk_export`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bulk_export` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exporter_id` int(11) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `comment` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `params` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:json)',
  `filename` varchar(760) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_625A30FDBE04EA9` (`job_id`),
  KEY `IDX_625A30FDB4523DE5` (`exporter_id`),
  KEY `IDX_625A30FD7E3C61F9` (`owner_id`),
  CONSTRAINT `FK_625A30FD7E3C61F9` FOREIGN KEY (`owner_id`) REFERENCES `user` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_625A30FDB4523DE5` FOREIGN KEY (`exporter_id`) REFERENCES `bulk_exporter` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_625A30FDBE04EA9` FOREIGN KEY (`job_id`) REFERENCES `job` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bulk_export`
--

LOCK TABLES `bulk_export` WRITE;
/*!40000 ALTER TABLE `bulk_export` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `bulk_export` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `bulk_exporter`
--

DROP TABLE IF EXISTS `bulk_exporter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bulk_exporter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) DEFAULT NULL,
  `label` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `writer` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:json)',
  PRIMARY KEY (`id`),
  KEY `IDX_6093500B7E3C61F9` (`owner_id`),
  CONSTRAINT `FK_6093500B7E3C61F9` FOREIGN KEY (`owner_id`) REFERENCES `user` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bulk_exporter`
--

LOCK TABLES `bulk_exporter` WRITE;
/*!40000 ALTER TABLE `bulk_exporter` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `bulk_exporter` VALUES (1,1,'CSV','BulkExport\\Writer\\CsvWriter','{\"writer\":{\"delimiter\":\",\",\"enclosure\":\"\\\"\",\"escape\":\"\\\\\",\"separator\":\" | \",\"resource_types\":[\"o:Item\"],\"metadata\":null,\"query\":\"\"}}'),(2,1,'OpenDocument spreadsheet (ods)','BulkExport\\Writer\\OpenDocumentSpreadsheetWriter','{\"writer\":{\"separator\":\" | \",\"resource_types\":[\"o:Item\"],\"metadata\":null,\"query\":\"\"}}'),(3,1,'OpenDocument text (odt)','BulkExport\\Writer\\OpenDocumentTextWriter','{\"writer\":{\"format_fields\":\"label\",\"resource_types\":[\"o:Item\"],\"metadata\":null,\"query\":\"\"}}'),(4,1,'TSV (tab-separated values)','BulkExport\\Writer\\TsvWriter','{\"writer\":{\"separator\":\" | \",\"resource_types\":[\"o:Item\"],\"metadata\":null,\"query\":\"\"}}'),(5,1,'Text','BulkExport\\Writer\\TextWriter','{\"writer\":{\"format_fields\":\"label\",\"resource_types\":[\"o:Item\"],\"metadata\":null,\"query\":\"\"}}');
/*!40000 ALTER TABLE `bulk_exporter` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `reference` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `severity` int(11) NOT NULL DEFAULT 0,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:json)',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `IDX_8F3F68C57E3C61F9` (`owner_id`),
  KEY `IDX_8F3F68C5BE04EA9` (`job_id`),
  KEY `IDX_8F3F68C5AEA34913` (`reference`),
  KEY `IDX_8F3F68C5F660D16B` (`severity`),
  CONSTRAINT `FK_8F3F68C57E3C61F9` FOREIGN KEY (`owner_id`) REFERENCES `user` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_8F3F68C5BE04EA9` FOREIGN KEY (`job_id`) REFERENCES `job` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `annotation_target`
--

DROP TABLE IF EXISTS `annotation_target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `annotation_target` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_9F53A3D6BF396750` FOREIGN KEY (`id`) REFERENCES `resource` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `annotation_target`
--

LOCK TABLES `annotation_target` WRITE;
/*!40000 ALTER TABLE `annotation_target` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `annotation_target` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `annotation`
--

DROP TABLE IF EXISTS `annotation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `annotation` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_2E443EF2BF396750` FOREIGN KEY (`id`) REFERENCES `resource` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `annotation`
--

LOCK TABLES `annotation` WRITE;
/*!40000 ALTER TABLE `annotation` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `annotation` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `custom_vocab`
--

DROP TABLE IF EXISTS `custom_vocab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_vocab` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_set_id` int(11) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `label` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `terms` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '(DC2Type:json)',
  `uris` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '(DC2Type:json)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8533D2A5EA750E8` (`label`),
  KEY `IDX_8533D2A5960278D7` (`item_set_id`),
  KEY `IDX_8533D2A57E3C61F9` (`owner_id`),
  CONSTRAINT `FK_8533D2A57E3C61F9` FOREIGN KEY (`owner_id`) REFERENCES `user` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_8533D2A5960278D7` FOREIGN KEY (`item_set_id`) REFERENCES `item_set` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_vocab`
--

LOCK TABLES `custom_vocab` WRITE;
/*!40000 ALTER TABLE `custom_vocab` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `custom_vocab` VALUES (1,NULL,1,'Annotation Body oa:hasPurpose',NULL,'[\"assessing\",\"bookmarking\",\"classifying\",\"commenting\",\"describing\",\"editing\",\"highlighting\",\"identifying\",\"linking\",\"moderating\",\"questioning\",\"replying\",\"tagging\"]',NULL),(2,NULL,1,'Annotation Target dcterms:format',NULL,'[\"application\\/json\",\"application\\/xml\",\"image\\/svg+xml\",\"application\\/wkt\"]',NULL),(3,NULL,1,'Annotation Target rdf:type',NULL,'[\"as:OrderedCollection\",\"as:OrderedCollectionPage\",\"dctype:Dataset\",\"dctype:MovingImage\",\"dctype:StillImage\",\"dctype:Sound\",\"dctype:Text\",\"oa:Choice\",\"oa:CssSelector\",\"oa:DataPositionSelector\",\"oa:FragmentSelector\",\"oa:HttpRequestState\",\"oa:RangeSelector\",\"oa:SvgSelector\",\"oa:TextPositionSelector\",\"oa:TextQuoteSelector\",\"oa:TimeState\",\"oa:XPathSelector\",\"o:Item\",\"o:ItemSet\",\"o:Media\"]',NULL),(4,NULL,1,'Annotation oa:motivatedBy',NULL,'[\"assessing\",\"bookmarking\",\"classifying\",\"commenting\",\"describing\",\"editing\",\"highlighting\",\"identifying\",\"linking\",\"moderating\",\"questioning\",\"replying\",\"tagging\"]',NULL);
/*!40000 ALTER TABLE `custom_vocab` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

--
-- Table structure for table `annotation_body`
--

DROP TABLE IF EXISTS `annotation_body`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `annotation_body` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_D819DB36BF396750` FOREIGN KEY (`id`) REFERENCES `resource` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `annotation_body`
--

LOCK TABLES `annotation_body` WRITE;
/*!40000 ALTER TABLE `annotation_body` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `annotation_body` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on: Wed, 13 Mar 2024 15:51:54 +0100
